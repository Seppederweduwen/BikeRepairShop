﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.DL.Repositories;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace ConsoleAppTestDL
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string conn = ConfigurationManager.ConnectionStrings["ADOconnSQL"].ConnectionString; 
            CustomerRepository repo = new CustomerRepository(conn);
            RepairOrderRepository repairOrderRepository = new RepairOrderRepository(conn);      
            //Testen db
            Customer c = new Customer("Jos", "jos@gmail.com", "Gent ");
            DateOnly _dateIn = new(2023, 1,1);
            DateOnly _dateOut = new(2023,2,2);
            double _discount = 0.15;
            bool _payed = false;
            double _costPayed = 25;
            Urgency _urgency = Urgency.Normal;
            c.SetId(1);
            RepairOrder repairOrder = new RepairOrder(_dateIn, _dateOut, c, _discount, _payed, _costPayed, _urgency);
            repairOrderRepository.AddRepairOrder(repairOrder);
            Console.WriteLine("end");


        }
    }
}