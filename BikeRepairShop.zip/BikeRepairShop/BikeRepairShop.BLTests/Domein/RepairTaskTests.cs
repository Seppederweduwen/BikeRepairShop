﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein.Tests
{
    [TestClass()]
    public class RepairTaskTests
    {
        [TestMethod()]

    }
}