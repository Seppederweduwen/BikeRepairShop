﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.Exceptions;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;
using System.Collections.ObjectModel;

namespace BikeRepairShop.BL.Interfaces
{
    public interface ICustomerRepository
    {
        void AddBike(Bike bike);
        void AddCustomer(Customer customer);
        void DeleteBike(Bike bike);
        void DeleteCustomer(Customer customer);
        List<BikeInfo> GetBikesInfo();
        public ObservableCollection<string> GetCustomers();
        Customer GetCustomer(int id);
        Customer GetCustomerWithoutBikes(int id);
        Customer GetCustomer2(int id);
        Customer GetCustomer(string email);
        public int GetCustomerId(string name);
        List<CustomerInfo> GetCustomersInfo(string? name = null);
        void UpdateBike(Bike bike);
        void UpdateCustomer(Customer customer);
        public ObservableCollection<string> GetAllBikesFromCustomer(int id);
        public Customer GetCustomerInfoByName(string name);
        int GetNumberOfBikes(string name);
    }
}
