﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Interfaces
{
    public interface IRepairmanRepository
    {
        void AddRepairman(Repairman repairman);
        void DeleteRepairman(Repairman repairman);
        void UpdateRepairman(Repairman repairman);
        List<RepairmanInfo> GetRepairmenInfo(string? name = null);
        Repairman GetRepairman(int? id);
        public ObservableCollection<string> GetRepairMen();
        public Repairman GetRepairman(string Name);
    }
}
