﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Interfaces
{
    public interface IRepairOrderRepository
    {
        void AddRepairOrder(RepairOrder repairOrder);
        public ObservableCollection<string> GetRepairActions();
        public List<RepairtaskInfo> GetRepairActionsInfo();
        public RepairAction GetRepairActionInfo(string RepairAction);
        public double GetCostMaterials(string description);
        public int GetTaskId(string description);
        public int GetNextRepairOrderId();
        public void SaveRepairTask(string repairAction, string repairMan, double CostMaterials, string customer, string bike, int repairOrderid);
        public void RemoveRepairTaskById(int repairOrderId);
        public List<RepairtaskInfo> GetAllTasksFromRepairOrderByCustomer(string customer);
        public List<RepairOrderInfo> GetRepairOrderInfos();
        public void DeleteRepairOrder(int customerId, double cost);
        public string GetCustomerNameByCustomerId(int customerId);
    }
}
