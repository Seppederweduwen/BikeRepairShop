﻿using System.Runtime.Serialization;

namespace BikeRepairShop.BL.Exceptions
{
    [Serializable]
    public class FactoryException : Exception
    {
        public FactoryException(string? message) : base(message)
        {
        }
        public FactoryException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}