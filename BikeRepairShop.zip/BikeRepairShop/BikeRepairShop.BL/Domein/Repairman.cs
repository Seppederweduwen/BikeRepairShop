﻿using BikeRepairShop.BL.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public class Repairman
    {
        public Repairman(int? iD, string name, double costPerHour, string email)
        {
            ID = iD;
            Name = name;
            CostPerHour = costPerHour;
            Email = email;
        }
        public int? ID { get; private set; }
        public string Name { get; private set; }
        public double CostPerHour { get; private set; }
        public string Email { get; private set; }
        public void SetId(int id)
        {
            if (id <= 0) throw new DomainException("Repairman-setid");

            ID = id;
        }
        public void SetName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new DomainException("customer-setname");
            }
            Name = name;
        }
        public void SetCostPerHour(int costperhour)
        {
            if (costperhour <= 0) throw new DomainException("Repairman-setid");

            CostPerHour = costperhour;
        }
        public void SetEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                throw new DomainException("customer-setemail");
            }
            Email = email;
        }
    }
}
