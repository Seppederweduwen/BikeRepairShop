﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public enum BikeType
    {
        regularBike, childBike, racingBike, mountainBike
    }
}
