﻿using BikeRepairShop.BL.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public class Repair
    {
        public Repair(Bike bike)
        {
            Bike = bike;
        }
        public Repair(int? id, Bike bike, List<RepairTask> repairTasks) : this(bike)
        {
            this.Id = id;
            this.repairTasks = repairTasks;
        }
        public Repair()
        {
        }
        public int? Id { get; private set; }
        public Bike Bike { get; set; }
        private List<RepairTask> repairTasks = new List<RepairTask>();
        public IReadOnlyList<RepairTask> RepairTasks() { return repairTasks.AsReadOnly(); }
        public void AddRepairTask(RepairTask repairTask)
        {
            if (repairTasks.Contains(repairTask)) throw new DomainException("Repair-addRepairTask");
            
            repairTasks.Add(repairTask);
        }
        public void RemoveRepairTask(RepairTask repairTask)
        {
            if (!repairTasks.Contains(repairTask)) throw new DomainException("Repair-removeRepairTask");

            repairTasks.Remove(repairTask);
        }
        public double Cost()
        {
            double cost = 0;
            foreach (RepairTask repairTask in repairTasks)
            {
                cost += repairTask.Cost();
            }
            return cost;
        }
        public override bool Equals(object? obj)
        {
            if (obj is Repair)
            {
                Repair compRepair = (Repair)obj;
                if (Id.HasValue && compRepair.Id.HasValue)
                {
                    if (Id == compRepair.Id) return true; else return false;
                }

                else
                {
                    return
                    EqualityComparer<Bike>.Default.Equals(Bike, compRepair.Bike) &&
                    EqualityComparer<List<RepairTask>>.Default.Equals(repairTasks, compRepair.repairTasks);
                }
            }
            else
            {
                return false;
            }

        }
        public void SetId(int id)
        {
            if (id <= 0) throw new DomainException("Repair-setId");

            if (!string.IsNullOrEmpty(this.Id.ToString())) throw new DomainException("Repair-SetId-Already-has-ID");

            this.Id = id;
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(Id, Bike);
        }

    }
}
