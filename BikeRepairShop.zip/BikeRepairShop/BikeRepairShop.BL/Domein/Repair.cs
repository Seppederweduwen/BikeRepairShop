﻿using BikeRepairShop.BL.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public class Repair
    {

        public Repair(Bike bike)
        {
            Bike = bike;
        }


        public Repair(int? id, Bike bike, List<RepairTask> repairTasks) : this(bike)
        {
            this.Id = id;
            this.repairTasks = repairTasks;
        }

        public Repair()
        {
        }


        public int? Id { get; private set; }
        public Bike Bike { get; private set; }
        private List<RepairTask> repairTasks = new List<RepairTask>();

        public IReadOnlyList<RepairTask> RepairTasks() { return repairTasks.AsReadOnly(); }

        public void AddRepairTask(RepairTask repairTask)
        {
            if (repairTasks.Contains(repairTask)) throw new DomainException("Repair-addRepairTask");
            
            repairTasks.Add(repairTask);
        }
        public void RemoveRepairTask(RepairTask repairTask)
        {
            if (!repairTasks.Contains(repairTask)) throw new DomainException("Repair-removeRepairTask");

            repairTasks.Remove(repairTask);
        }

        //Moet hier een controle structuur? en moet ik hiervoor ook een test schrijven?
        //Volgens mij niet maar ik ben het niet zeker
        public double Cost()
        {
            double cost = 0;
            foreach (RepairTask repairTask in repairTasks)
            {
                cost += repairTask.Cost();
            }
            return cost;
        }

        public override bool Equals(object? obj)
        {
            if (obj is Repair)
            {
                Repair compRepair = (Repair)obj;
                if (Id.HasValue && compRepair.Id.HasValue)
                {
                    if (Id == compRepair.Id) return true; else return false;
                }

                else
                {
                    return
                    EqualityComparer<Bike>.Default.Equals(Bike, compRepair.Bike) &&
                    EqualityComparer<List<RepairTask>>.Default.Equals(repairTasks, compRepair.repairTasks);
                }
            }
            else
            {
                return false;
            }

        }
        //TODO dit eens nakijken of het wel dit moet doen
        public void SetId(int id)
        {
            //Ik denk dat we dit gewoon moeten doen met deze methode

            //Als er nog geen id aanwezig is dan pas vult hij het de id in
            if (id <= 0) throw new DomainException("Repair-setId");

            if (!string.IsNullOrEmpty(this.Id.ToString())) throw new DomainException("Repair-SetId-Already-has-ID");

            this.Id = id;
        }



        // bij twijfel kan dit weggelaten worden
        public override int GetHashCode()
        {
            return HashCode.Combine(Id, Bike);
        }

        
    }
}
