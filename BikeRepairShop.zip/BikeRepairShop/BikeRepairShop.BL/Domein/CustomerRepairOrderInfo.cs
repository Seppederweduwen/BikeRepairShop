﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public class CustomerRepairOrderInfo
    {
        public CustomerRepairOrderInfo(int repairOrderid, double? cost, bool payed, DateOnly orderDate)
        {
            RepairOrderid = repairOrderid;
            Cost = cost;
            Payed = payed;
            OrderDate = orderDate;
        }

        public int RepairOrderid { get; }
        public double? Cost { get; }
        public bool Payed { get; }
        public DateOnly OrderDate { get; }
    }
}
