﻿using BikeRepairShop.BL.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein;

public class Customer
{
    public Customer(string name, string email, string address)
    {
        SetName(name);
        SetEmail(email);
        SetAddress(address);
    }
    public Customer(string name)
    {
        SetName(name);
    }
    public Customer(int id, string name, string email, string address, List<Bike> bikes) : this(name, email, address)
    {
        SetId(id);
        this.bikes = bikes;
        foreach (Bike bike in bikes) { bike.SetCustomer(this); }
    }
    public Customer(int id, string name, string email, string address) : this(name, email, address)
    {
        SetId(id);
    }
    public int? ID { get; private set; }
    public string Name { get; private set; }
    public string Email { get; private set; }
    public string Address { get; private set; }
    public List<Bike> bikes { get; private set; } = new List<Bike>();
    public IReadOnlyList<Bike> Bikes() { return bikes.AsReadOnly(); }
    private List<CustomerRepairOrderInfo> CustomerRepairOrderInfos = new List<CustomerRepairOrderInfo>();
    public IReadOnlyList<CustomerRepairOrderInfo> GetCustomerRepairOrderInfos() 
    { 
        return CustomerRepairOrderInfos.AsReadOnly();
    }
    public void AddBike(Bike bike)
    {
        if (bikes.Contains(bike)) throw new DomainException("Bike-addbike");
        if (bike == null) throw new DomainException("Customer");
        bikes.Add(bike);

        if (bike.Customer!=this) bike.SetCustomer(this);
    }
    public void RemoveBike(Bike bike)
    {
        if (!bikes.Contains(bike)) throw new DomainException("Bike-removebike");
        bikes.Remove(bike);

        if (bike.Customer == this) bike.RemoveCustomer();
    }
    public void SetName(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new DomainException("customer-setname");
        }
        Name = name;
    }
    public void SetEmail(string email)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            throw new DomainException("customer-setemail");
        }
        Email = email;
    }
    public void SetAddress(string address)
    {
        if (string.IsNullOrWhiteSpace(address))
        {
            throw new DomainException("customer-setaddress");
        }
        Address = address;
    }
    public void SetId(int id)
    {
        if (id <= 0) throw new DomainException("customer-setid");
        if (!string.IsNullOrEmpty(this.ID.ToString())) throw new DomainException("Customer-setId-IdAlreadySet");
        ID = id;
    }
}
