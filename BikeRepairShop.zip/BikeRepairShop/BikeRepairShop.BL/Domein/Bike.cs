﻿using BikeRepairShop.BL.Exceptions;
using BikeRepairShop.BL.Managers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Domein
{
    public class Bike
    {
        public Bike(BikeType bikeType,  double purchaseCost,  string? description)
        {
            Description = description;
            PurchaseCost = purchaseCost;
            BikeType = bikeType;
        }
        public Bike(int? iD, BikeType bikeType, double purchaseCost, string? description)
        {
            ID = iD;
            Description = description;
            PurchaseCost = purchaseCost;
            BikeType = bikeType;
        }
        public int? ID { get; set; }
        public string? Description { get; set; }
        public double PurchaseCost { get; private set; }
        public BikeType BikeType { get; set; }
        public Customer Customer { get; private set; }

        public override bool Equals(object? obj)
        {
            return obj is Bike bike &&
                   Description == bike.Description &&
                   PurchaseCost == bike.PurchaseCost &&
                   BikeType == bike.BikeType;
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(Description, PurchaseCost, BikeType);
        }
        public void SetId(int id)
        {
            if (id <= 0) throw new DomainException("customer-setid");
            if (!string.IsNullOrEmpty(this.ID.ToString())) throw new DomainException("Bike-setId-IdAlreadyeSet");

            ID = id;
        }
        public void SetPurchaseCost(double cost)
        {
            if (cost <= 0)
            {
                throw new DomainException("Bike-setpurchasecost");
            }
            PurchaseCost = cost;
        }
        public void SetCustomer (Customer customer)
        {
            if(customer == null)
            {
                throw new DomainException("SetCustomer");
            } else
            {
                if (!customer.Bikes().Contains(this))
                {
                customer.AddBike(this);
                }
                Customer = customer;
            }
        }
        public void RemoveCustomer()
        {
            Customer = null;
        }
    }
}
