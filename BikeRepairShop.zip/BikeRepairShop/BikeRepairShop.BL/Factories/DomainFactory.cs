﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Exceptions;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Factories
{
    public static class DomainFactory
    {
        public static Bike NewBike(BikeInfo bikeInfo)
        {
            try
            {
                return new Bike(bikeInfo.BikeType, bikeInfo.PurchaseCost, bikeInfo.Description);
            }
            catch (Exception ex)
            {
                throw new FactoryException("NewBike", ex);
            }
            
           
        }
        public static Bike ExistingBike(int? id, BikeType bikeType, double purchaseCost, string? description)
        {
            try
            {
                return new Bike(id, bikeType, purchaseCost, description);
            }
            catch (Exception ex) { throw new DomainException("NewBike", ex); }
        }
        public static Customer ExistingCustomer(int id, string name, string email, string address, List<Bike> bikes)
        {
            try
            {
                return new Customer(id, name, email, address, bikes);
            }
            catch (Exception ex) { throw new DomainException("ExistingCustomer", ex); }
        }
        public static Customer ExistingCustomerWithoutBikes(int id, string name, string email, string address)
        {
            try
            {
                return new Customer(id, name, email, address);
            }
            catch (Exception ex) { throw new DomainException("ExistingCustomerWithoutBikes", ex); }
        }
        public static Customer ExistingCustomerInfoByName(int id, string name, string email, string address)
        {
            try
            {
                return new Customer(id, name, email, address);
            }
            catch (Exception ex) { throw new DomainException("ExistingCustomerByName", ex); }
        }
        public static Customer NewCustomer(CustomerInfo customerInfo)
        {
            try
            {
                return new Customer(customerInfo.Name, customerInfo.Email, customerInfo.Address);
            }
            catch (Exception ex) { throw new DomainException("NewCustomer", ex); }
        }
        public static Repairman NewRepairman(RepairmanInfo repairmanInfo) 
        {
            try
            {
                return new Repairman(repairmanInfo.ID, repairmanInfo.Name, Convert.ToInt32(repairmanInfo.CostPerHour), repairmanInfo.Email);
            }
            catch (Exception ex) { throw new DomainException("NewRepairman", ex); }
        }
        public static Repairman ExistingRepairman(int? ID, string Name, int CostPerHour, string Email)
        {
            try
            {
                return new Repairman(ID, Name, CostPerHour, Email);
            }
            catch (Exception ex) { throw new DomainException("ExistingRepairman", ex); }
        }
        public static RepairAction ExistingRepairAction(int id, int repairTime, string description, double costMaterials)
        {
            try
            {
                return new RepairAction(id, description, repairTime, costMaterials);
            }
            catch (Exception ex) { throw new DomainException("NewRepairAction", ex); }
        }
        public static RepairActionInfo NewRepairtaskInfo(int id, int repairTime, string description, double costMaterials)
        {
            try
            {
                return new RepairActionInfo(id, costMaterials, description, repairTime);
            }
            catch (Exception ex) { throw new DomainException("NewRepaitaskInfo", ex) ; }
        }
    }
}
