﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.DTO
{
    public class CustomerInfo
    {
        public CustomerInfo(int? iD, string name, string email, string address, int nrOfBikes, double totalBikesValue)
        {
            ID = iD;
            Name = name;
            Email = email;
            Address = address;
            NrOfBikes = nrOfBikes;
            TotalBikesValue = totalBikesValue;
        }
        public int? ID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public int NrOfBikes { get; set; }
        public double TotalBikesValue { get; set; }
        public override string? ToString()
        {
            return $"{ID},{Name},{Address},{Email}";
        }
    }
}
