﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.DTO
{
    public class BikeInfo
    {
        public BikeInfo(int? iD, string description, BikeType bikeType, double purchaseCost, int customerId,
            string customerDescription)
        {
            ID = iD;
            Description = description;
            BikeType = bikeType;
            PurchaseCost = purchaseCost;
            Customer = (customerId, customerDescription);
        }

        public int? ID { get; set; } //BikeId
        public string Description { get; set; }
        public BikeType BikeType { get; set; }
        public double PurchaseCost { get; set; }
        public (int id, string description) Customer { get; set; }

        public override bool Equals(object? obj)
        {
            return obj is BikeInfo info &&
                   ID == info.ID &&
                   Description == info.Description &&
                   BikeType == info.BikeType &&
                   PurchaseCost == info.PurchaseCost &&
                   Customer.Equals(info.Customer);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ID, Description, BikeType, PurchaseCost, Customer);
        }
    }
}
