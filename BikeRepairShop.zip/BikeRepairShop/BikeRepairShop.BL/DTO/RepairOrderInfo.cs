﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.DTO
{
    public class RepairOrderInfo
    {
        public RepairOrderInfo(int customerId, DateTime dateIn, DateTime dateOut, double cost, double discount, string urgency, int payed)
        {
            CustomerId = customerId;
            DateIn = dateIn;
            DateOut = dateOut;
            Cost = cost;
            Discount = discount;
            Urgency = urgency;
            Payed = payed;
        }

        public int CustomerId { get; set; }
        public DateTime DateIn { get; set; }
        public DateTime DateOut { get; set; }
        public double Cost { get; set; }
        public double Discount { get; set; }
        public string Urgency { get; set; }
        public int Payed { get; set; }

    }
}
