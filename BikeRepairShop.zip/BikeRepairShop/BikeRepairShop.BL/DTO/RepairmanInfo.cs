﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.DTO
{
    public class RepairmanInfo
    {
        public RepairmanInfo(int? id, string name, decimal costPerHour, string email)
        {
            ID = id;
            Name = name;
            CostPerHour = costPerHour;
            Email = email;
        }
        public int? ID { get; set; }
        public string Name { get; set; }
        public decimal CostPerHour { get; set; }
        public string Email { get; set; }
    }
}
