﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.DTO
{
    public class RepairtaskInfo
    {
        public RepairtaskInfo(int iD, double costMaterials, string description, int repairTime)
        {
            ID = iD;
            this.repairTime = repairTime;
            this.description = description;
            this.costMaterials = costMaterials;
        }

        public int ID { get; set; }
        public int repairTime { get; set; }
        public string description { get; set; }
        public double costMaterials { get; set; }

    }
}
