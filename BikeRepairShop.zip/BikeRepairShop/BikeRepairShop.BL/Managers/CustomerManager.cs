﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Exceptions;
using BikeRepairShop.BL.Factories;
using BikeRepairShop.BL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Managers
{
    public class CustomerManager
    {
        private ICustomerRepository repo;
        public CustomerManager(ICustomerRepository repo)
        {
            this.repo = repo;
        }
        public void AddBike(BikeInfo bikeInfo)
        {
            try
            {
                if (bikeInfo == null) throw new ManagerException("CustomerManager");

                Customer customer = repo.GetCustomer(bikeInfo.Customer.id);
                Bike bike = DomainFactory.NewBike(bikeInfo);
                customer.AddBike(bike);
                repo.AddBike(bike);
                bikeInfo.ID = bike.ID;
            }
            catch(Exception ex)
            {
                throw new ManagerException("AddBike", ex);
            }
        }
        public void AddFirstBike(BikeInfo bikeInfo)
        {
            try
            {
                if (bikeInfo == null) throw new ManagerException("CustomerManager");

                Customer customer = repo.GetCustomerWithoutBikes(bikeInfo.Customer.id);
                Bike bike = DomainFactory.NewBike(bikeInfo);
                customer.AddBike(bike);
                repo.AddBike(bike);
                bikeInfo.ID = bike.ID;
            }
            catch (Exception ex)
            {
                throw new ManagerException("AddBike", ex);
            }
        }
        public void UpdateBike(BikeInfo bikeInfo)
        {
            try
            {
                if (bikeInfo == null) throw new ManagerException("CustomerManager");
                Customer customer = repo.GetCustomer(bikeInfo.Customer.id);
                Bike bike = customer.Bikes().Where(x => x.Customer.ID == bikeInfo.Customer.id).First();
                bike.ID = bikeInfo.ID;
                bike.Description = bikeInfo.Description;
                bike.BikeType = bikeInfo.BikeType;
                bike.SetPurchaseCost(bikeInfo.PurchaseCost);
                repo.UpdateBike(bike);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public void DeleteBike(BikeInfo bikeInfo)
        {
            try
            {
                if (bikeInfo == null) throw new ManagerException("CustomerManager");
                Customer customer = repo.GetCustomer(bikeInfo.Customer.id);
                Bike bike = customer.Bikes().Where(x => x.ID == bikeInfo.ID).First();
                //Bike bike = DomainFactory.ExistingBike(bikeInfo,customer);
                customer.RemoveBike(bike);
                repo.DeleteBike(bike);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public List<BikeInfo> GetBikeInfos()
        {
            try
            {
                return repo.GetBikesInfo();
            }
            catch(Exception ex) { throw new ManagerException("GetBikesInfo", ex); }
        }
        public void AddCustomer(CustomerInfo customerInfo)
        {
            try
            {
                if (customerInfo == null) throw new ManagerException("CustomerManager");
                Customer customer = DomainFactory.NewCustomer(customerInfo);
                repo.AddCustomer(customer);
                customerInfo.ID = customer.ID;
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public void UpdateCustomer(CustomerInfo customerInfo)
        {
            try
            {
                if (customerInfo == null) throw new ManagerException("CustomerManager");
                if (!customerInfo.ID.HasValue) throw new ManagerException("CustomerManager");
                Customer customer = repo.GetCustomer((int)customerInfo.ID);
                customer.SetAddress(customerInfo.Address);
                customer.SetName(customerInfo.Name);
                customer.SetEmail(customerInfo.Email);
                repo.UpdateCustomer(customer);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public void UpdateCustomerWithoutBikes(CustomerInfo customerInfo)
        {
            try
            {
                if (customerInfo == null) throw new ManagerException("CustomerManager");
                if (!customerInfo.ID.HasValue) throw new ManagerException("CustomerManager");
                Customer customer = repo.GetCustomerWithoutBikes((int)customerInfo.ID);
                customer.SetAddress(customerInfo.Address);
                customer.SetName(customerInfo.Name);
                customer.SetEmail(customerInfo.Email);
                repo.UpdateCustomer(customer);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public void DeleteCustomer(CustomerInfo customerInfo)
        {
            try
            {
                if (customerInfo == null) throw new ManagerException("CustomerManager");
                if (!customerInfo.ID.HasValue) throw new ManagerException("CustomerManager");
                Customer customer = repo.GetCustomer((int)customerInfo.ID);
                repo.DeleteCustomer(customer);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public Customer GetCustomer(int id)
        {
            try
            {
                return repo.GetCustomer(id);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public List<CustomerInfo> GetCustomersInfo()
        {
            try
            {
                return repo.GetCustomersInfo();
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public List<CustomerInfo> GetCustomersInfo(string name)
        {
            try
            {
                return repo.GetCustomersInfo(name);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public Customer GetCustomer(string email)
        {
            try
            {
                return repo.GetCustomer(email);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
    }
}
