﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Exceptions;
using BikeRepairShop.BL.Factories;
using BikeRepairShop.BL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Managers
{
    public class RepairmanManager
    {
        private IRepairmanRepository repo;
        public RepairmanManager(IRepairmanRepository repo)
        {
            this.repo = repo;
        }
        public void AddRepairman(RepairmanInfo repairmanInfo)
        {
            try
            {
                if (repairmanInfo == null) throw new ManagerException("RepairmanManager");
                Repairman repairman = DomainFactory.NewRepairman(repairmanInfo);
                repo.AddRepairman(repairman);
                repairmanInfo.ID = repairman.ID;
            }
            catch (Exception ex)
            {
                throw new ManagerException("AddBike", ex);
            }
        }
        public void UpdateRepairman(RepairmanInfo repairmanInfo)
        {
            try
            {
                if (repairmanInfo == null) throw new ManagerException("RepairmanManager");
                Repairman repairman = repo.GetRepairman(repairmanInfo.ID);
                repairman.SetId(Convert.ToInt32(repairmanInfo.ID));
                repairman.SetName(repairmanInfo.Name);
                repairman.SetCostPerHour(Convert.ToInt32(repairmanInfo.CostPerHour));
                repairman.SetEmail(repairmanInfo.Email);
                repo.UpdateRepairman(repairman);
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public void DeleteRepairman(RepairmanInfo repairmanInfo)
        {
            try
            {

            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public List<RepairmanInfo> GetRepairmenInfo()
        {
            try
            {
                return repo.GetRepairmenInfo();
            }
            catch (Exception ex) { throw new ManagerException("RepairmanManager", ex); }
        }
    }
}
