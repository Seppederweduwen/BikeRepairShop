﻿using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Exceptions;
using BikeRepairShop.BL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.BL.Managers
{
    public class RepairorderManager
    {
        private IRepairOrderRepository repo;
        public RepairorderManager(IRepairOrderRepository repo)
        {
            this.repo = repo;
        }
        public List<RepairActionInfo> GetRepairActionsInfo()
        {
            try
            {
                return repo.GetRepairActionInfo();
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
        public List<RepairOrderInfo> GetRepairOrderInfo()
        {
            try
            {
                return repo.GetRepairOrderInfos();
            }
            catch (Exception ex) { throw new ManagerException("CustomerManager", ex); }
        }
    }
}
