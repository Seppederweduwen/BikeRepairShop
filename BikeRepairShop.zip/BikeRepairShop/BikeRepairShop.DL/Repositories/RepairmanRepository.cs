﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Factories;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.DL.Exceptions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.DL.Repositories
{
    public class RepairmanRepository : IRepairmanRepository
    {
        private string connectionString;
        public RepairmanRepository(string connectionString) 
        {
            this.connectionString = connectionString;
        }
        public void AddRepairman(Repairman repairman)
        {
            try
            {
                string sql = "INSERT INTO dbo.RepairMan(Name, CostPerHour, Email, Status) output INSERTED.ID VALUES (@name, @costperhour, @email, @status)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;

                    command.Parameters.AddWithValue("@name", repairman.Name );
                    command.Parameters.AddWithValue("@costperhour", repairman.CostPerHour);
                    command.Parameters.AddWithValue("@email", repairman.Email);
                    command.Parameters.AddWithValue("@status", 1);

                    int bid = (int)command.ExecuteScalar();
                    repairman.SetId(bid);
                }
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("AddBike", ex);
            }
        }
        public void DeleteRepairman(Repairman repairman)
        {
            try
            {
                string sqlDel = "UPDATE dbo.repairman SET status=0 WHERE email=@email and status=1";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand command = conn.CreateCommand())
                {
                    conn.Open();
                    command.CommandText = sqlDel;
                    command.Parameters.AddWithValue("@email", repairman.Email);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("DeleteRepairman", ex);
            }
        }
        public void UpdateRepairman(Repairman repairman)
        {
            try
            {
                string sql = "UPDATE dbo.repairman SET Name=@name, Email=@email, CostPerHour=@costperhour WHERE Id=@id and status=1";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@name", repairman.Name);
                    command.Parameters.AddWithValue("@email", repairman.Email);
                    command.Parameters.AddWithValue("@costperhour", repairman.CostPerHour);
                    command.Parameters.AddWithValue("@id", repairman.ID);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("UpdateRepairman", ex); }
        }
        public int GetNextId()
        {
            int number = 0;
            string sql = "SELECT TOP 1 Id FROM dbo.Repairman ORDER BY Id DESC";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;

                int output = (int)command.ExecuteScalar();
                output = output + 1;
                return output;
            }

        }
        public List<RepairmanInfo> GetRepairmenInfo(string? name = null)
        {
            try
            {
                string sql;
                sql = "SELECT Id, Name, CostPerHour, Email FROM dbo.Repairman WHERE Status = 1";
                List<RepairmanInfo> repairmen = new List<RepairmanInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    IDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        repairmen.Add(new RepairmanInfo((int)reader["Id"], (string)reader["Name"], (int)reader["CostPerHour"] ,(string)reader["Email"]));
                    }
                    reader.Close();
                    return repairmen;
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetRepairmenInfo", ex); }
        }
        public Repairman GetRepairman(int? id)
        {
            try
            {
                string sql = "SELECT Name, CostPerHour, Email FROM dbo.Repairman WHERE Status = 1 AND Id = @id";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    sqlCommand.Parameters.AddWithValue("@id", id);
                    IDataReader reader = sqlCommand.ExecuteReader();

                    string name = "";
                    string email = "";
                    int costperhour = 0;
                    bool firstLine = true;

                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            name = (string)reader["Name"];
                            costperhour = (int)reader["CostPerHour"];
                            email = (string)reader["Email"];
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingRepairman(id, name, costperhour, email);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetRepairman", ex); }
        }
        public ObservableCollection<string> GetRepairMen()
        {
            string sql = "SELECT Name FROM dbo.Repairman";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand sqlCommand = connection.CreateCommand())
            {
                connection.Open();
                sqlCommand.CommandText = sql;
                IDataReader reader = sqlCommand.ExecuteReader();

                string name = "";
                ObservableCollection<string> repairmen = new ObservableCollection<string>();

                while (reader.Read())
                {
                    name = (string)reader["Name"];
                    repairmen.Add(name);
                }
                reader.Close();
                return repairmen;
            }
        }
        public Repairman GetRepairman(string Name)
        {
            try
            {
                string sql = "SELECT Id, CostPerHour, Email FROM dbo.Repairman WHERE Status = 1 AND Name = @name";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    sqlCommand.Parameters.AddWithValue("@name", Name);
                    IDataReader reader = sqlCommand.ExecuteReader();

                    int id = 0;
                    string email = "";
                    int costperhour = 0;
                    bool firstLine = true;

                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            id = (int)reader["id"];
                            costperhour = (int)reader["CostPerHour"];
                            email = (string)reader["Email"];
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingRepairman(id, Name, costperhour, email);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetRepairman", ex); }
        }
    }
}
