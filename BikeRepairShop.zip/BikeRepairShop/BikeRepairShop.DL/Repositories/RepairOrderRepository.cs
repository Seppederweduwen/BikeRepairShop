﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Xml.Linq;
using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Factories;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.DL.Exceptions;

namespace BikeRepairShop.DL.Repositories
{
    public class RepairOrderRepository : IRepairOrderRepository
    {
        private string connectionString;

        public RepairOrderRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }
        private void AddRepairTask(int repairId, RepairTask repairTask, SqlCommand cmd)
        {
            string sql = "";
            cmd.CommandText = sql;
            cmd.Parameters.Clear();
            //parameters toevoegen
            int rtid = (int)cmd.ExecuteScalar();
            repairTask.SetId(rtid);
        }
        private void AddRepair(int repairOrderId, Repair repair, SqlCommand cmd)
        {
            string sql = "";
            cmd.CommandText = sql;
            cmd.Parameters.Clear();
            //parameters toevoegen
            int rid= (int)cmd.ExecuteScalar();
            repair.SetId(rid);
            foreach (RepairTask rt in repair.RepairTasks())
            {
                AddRepairTask(rid, rt, cmd);
            }
        }
        public void AddRepairOrder(RepairOrder repairOrder)
        {
            try
            {
                string sql = "INSERT INTO RepairOrder(CustomerId, DateIn, DateOut, Cost, Discount, Urgency, Payed, Status) " +
                    "values(@customerid, @datein, @dateout, @cost, @discount, @urgency, @payed, @status)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {

                    connection.Open();
                    command.CommandText = sql;

                    //@customerid
                    command.Parameters.AddWithValue("@customerid", repairOrder.Customer.ID);

                    //@datein
                    DateTime dtIn = repairOrder.DateIn.ToDateTime(TimeOnly.MinValue);
                    command.Parameters.AddWithValue("@datein", dtIn);

                    //@dateout
                    DateOnly dtOut = repairOrder.DateOut.GetValueOrDefault();
                    DateTime datetimeOut = dtOut.ToDateTime(TimeOnly.MinValue);
                    command.Parameters.AddWithValue("@dateout", datetimeOut);

                    //@cost
                    command.Parameters.AddWithValue("@cost", repairOrder.Cost());

                    //@discount
                    command.Parameters.AddWithValue("@discount", repairOrder.Discount);

                    //@urgency
                    string strUrgency = repairOrder.Urgency.ToString();
                    command.Parameters.AddWithValue("@urgency", strUrgency);

                    //als het al betaald is '1' in de database zetten
                    if (repairOrder.Payed == true) command.Parameters.AddWithValue("@payed", 1);
                    //als het nog niet betaald is '0' in de database zetten
                    else if (repairOrder.Payed == false) command.Parameters.AddWithValue("@payed", 0);

                    //@status
                    //voor de soft delete status op 0 zetten (zou ik doen)
                    command.Parameters.AddWithValue("@status", 1);

                    command.ExecuteNonQuery();
                    connection.Close();
                    
                }
            }
            catch (Exception ex)
            {
                throw new RepairOrderRepositoryException("addrepairorder", ex);
            }
        }
        public ObservableCollection<string> GetRepairActions()
        {
            try
            {
                string sql = "SELECT description FROM dbo.RepairAction";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    IDataReader reader = sqlCommand.ExecuteReader();

                    string repairtaskName = "";
                    ObservableCollection<string> repairtasks = new ObservableCollection<string>();

                    while (reader.Read())
                    {
                        repairtaskName = (string)reader["description"];
                        repairtasks.Add(repairtaskName);
                    }
                    reader.Close();
                    return repairtasks;
                }
            }
            catch (Exception ex)
            {
                throw new RepairOrderRepositoryException("GetRepairtasks", ex);
            }
            
        }
        public List<RepairtaskInfo> GetRepairActionsInfo()
        {
            try
            {
                string sql;
                sql = "SELECT * FROM dbo.RepairAction";

                List<RepairtaskInfo> repairtaskInfos = new List<RepairtaskInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    IDataReader reader = command.ExecuteReader();

                    int id = 0 ;
                    int repairTime = 0;
                    string description = "";
                    int costMaterials = 0;

                    while (reader.Read())
                    {
                        id = (int)reader["id"];
                        repairTime = (int)reader["repairTime"];
                        costMaterials = (int)reader["costMaterials"];
                        description = (string)reader["description"];

                        repairtaskInfos.Add(new RepairtaskInfo (id,costMaterials, description,repairTime ));
                    }
                    reader.Close();
                    return repairtaskInfos;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetRepairActionInfo", ex); }
        }
        public RepairAction GetRepairActionInfo(string description)
        {
            try
            {
                string sql;
                sql = "SELECT id, repairTime, costMaterials  FROM dbo.RepairAction WHERE description = @description";

                List<RepairtaskInfo> repairtaskInfos = new List<RepairtaskInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("description", description);
                    IDataReader reader = command.ExecuteReader();

                    int id = 0;
                    int repairTime = 0;
                    int costMaterials = 0;

                    while (reader.Read())
                    {
                        id = (int)reader["id"];
                        repairTime = (int)reader["repairTime"];
                        costMaterials = (int)reader["costMaterials"];

                    }
                    reader.Close();
                    return DomainFactory.ExistingRepairAction(id, repairTime, description, costMaterials); ;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetRepairtaskInfo", ex); }
        }
        public double GetCostMaterials(string description)
        {
            try
            {
                string sql;
                sql = "SELECT costMaterials FROM dbo.RepairAction WHERE description = @description";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("description", description);
                    IDataReader reader = command.ExecuteReader();

                    double costMaterials = 0;

                    while (reader.Read())
                    {
                        costMaterials = (int)reader["costMaterials"];
                    }
                    reader.Close();
                    return costMaterials;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetCostMaterialsInfo", ex); }
        }
        public int GetTaskId(string description)
        {
            try
            {
                string sql;
                sql = "SELECT id FROM dbo.RepairAction WHERE description = @description";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("description", description);
                    IDataReader reader = command.ExecuteReader();

                    int id = 0;

                    while (reader.Read())
                    {
                        id = (int)reader["id"];
                    }
                    reader.Close();
                    return id;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetTaskId", ex); }
        }
        public int GetNextRepairOrderId()
        {
            try
            {
                string sql;
                sql = "SELECT TOP 1 Id FROM dbo.RepairOrder ORDER BY Id DESC";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    IDataReader reader = command.ExecuteReader();
                    int id = 0;
                    while (reader.Read())
                    {
                        id = (int)reader["Id"];
                    }
                    reader.Close();
                    return id + 1;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetRepairOrderId", ex); }
        }
        public void SaveRepairTask(string repairAction, string repairMan, double CostMaterials, string customer, string bike, int repairOrderid)
        {
            try
            {
                string sql;
                sql = "INSERT INTO dbo.RepairTask (RepairAction, RepairMan, CostMaterials, Customer, Bike, RepairOrderid) VALUES (@repairAction, @repairMan, @CostMaterials, @customer, @bike, @repairOrderid)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@repairAction", repairAction);
                    command.Parameters.AddWithValue("@repairMan", repairMan);
                    command.Parameters.AddWithValue("@CostMaterials", CostMaterials);
                    command.Parameters.AddWithValue("@customer", customer);
                    command.Parameters.AddWithValue("@bike", bike);
                    command.Parameters.AddWithValue("@repairOrderid", repairOrderid);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("SaveRepairTask", ex); }
        }
        public void RemoveRepairTaskById(int repairOrderId)
        {
            try
            {
                string sql;
                sql = "DELETE FROM dbo.RepairTask WHERE RepairOrderId = @repairOrderId";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@repairOrderId", repairOrderId);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("RemoveRepairTaskById", ex); }
        } 
        public List<RepairOrderInfo> GetRepairOrderInfos()
        {
            try
            {
                string sql;
                sql = "SELECT * FROM dbo.RepairOrder WHERE status = 1";

                List<RepairOrderInfo> repairOrderInfos = new List<RepairOrderInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    IDataReader reader = command.ExecuteReader();

                    int id = 0;
                    int customerId = 0;
                    DateTime dateIn;
                    DateTime dateOut;
                    double cost = 0;
                    double discount = 0;
                    string urgency;
                    byte payed =0;

                    while (reader.Read())
                    {
                        id = (int)reader["Id"];
                        customerId = (int)reader["CustomerId"];
                        dateIn = (DateTime)reader["DateIn"];
                        dateOut = (DateTime)reader["DateOut"];
                        cost = (double)reader["Cost"];
                        discount = (double)reader["Discount"];
                        urgency = (string)reader["Urgency"];
                        payed = (byte)reader["Payed"];

                        repairOrderInfos.Add(new RepairOrderInfo(customerId, dateIn, dateOut, cost, discount, urgency, payed));
                    }
                    reader.Close();
                    return repairOrderInfos;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetRepairActionInfo", ex); }
        }
        public void DeleteRepairOrder(int customerId, double cost)
        {
            try
            {
                string sqlDel = "UPDATE dbo.repairOrder SET status=0 WHERE customerId=@customerid and cost=@cost and status=1";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand command = conn.CreateCommand())
                {
                    conn.Open();
                    command.CommandText = sqlDel;
                    command.Parameters.AddWithValue("@customerid", customerId);
                    command.Parameters.AddWithValue("@cost", cost);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("DeleteRepairOrder", ex);
            }
        }
        public int GetRepairtime(string repairAction)
        {
            try
            {
                string sql;
                sql = "SELECT repairtime FROM dbo.RepairAction WHERE description = @repairAction";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@repairAction", repairAction);
                    IDataReader reader = command.ExecuteReader();

                    int repairtime = 0;

                    while (reader.Read())
                    {
                        repairtime = (int)reader["repairtime"];
                    }
                    reader.Close();
                    return repairtime;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetRepairtime", ex); }
        }
        public List<RepairtaskInfo> GetAllTasksFromRepairOrderByCustomer(string customer)
        {
            try
            {
                string sql;
                sql = "SELECT * FROM dbo.RepairTask WHERE Customer = @Customer";

                List<RepairtaskInfo> repairtaskInfos = new List<RepairtaskInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@Customer", customer);
                    IDataReader reader = command.ExecuteReader();

                    int id = 0;
                    string repairAction;
                    string repairMan = "";
                    int costMaterials = 0;
                    string bike = "";
                    int repairOrderid = 0;

                    while (reader.Read())
                    {
                        id = (int)reader["Id"];
                        repairAction = (string)reader["RepairAction"];
                        repairMan = (string)reader["RepairMan"];
                        costMaterials = Convert.ToInt32(reader["CostMaterials"]); // Conversie naar int
                        bike = (string)reader["Bike"];
                        repairOrderid = (int)reader["RepairOrderid"];

                        repairtaskInfos.Add(new RepairtaskInfo(id, costMaterials, repairAction, GetRepairtime(repairAction)));
                    }
                    reader.Close();
                    return repairtaskInfos;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetAllTasksFromRepairOrderByCustomer", ex); }
        }
        public string GetCustomerNameByCustomerId(int customerId)
        {
            try
            {
                string sql;
                sql = "SELECT name FROM dbo.Customer WHERE id = @customerId";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("customerId", customerId);
                    IDataReader reader = command.ExecuteReader();

                    string name = "";

                    while (reader.Read())
                    {
                        name = (string)reader["name"];
                    }
                    reader.Close();
                    return name;
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("GetCustomerNameByCustomerId", ex); }
        }
        public void UpdateRepairOrder(RepairOrder repairOrder)
        {
            try
            {
                string sql;
                sql = "UPDATE dbo.RepairOrder SET DateIn = @dateIn, DateOut = @dateOut, Cost = @cost, Discount = @discount, Urgency = @urgency, Payed = @payed WHERE Id = @id";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@dateIn", repairOrder.DateIn);
                    command.Parameters.AddWithValue("@dateOut", repairOrder.DateOut);
                    command.Parameters.AddWithValue("@cost", repairOrder.Cost);
                    command.Parameters.AddWithValue("@discount", repairOrder.Discount);
                    command.Parameters.AddWithValue("@urgency", repairOrder.Urgency);
                    command.Parameters.AddWithValue("@payed", repairOrder.Payed);
                    command.Parameters.AddWithValue("@id", repairOrder.Id);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw new RepairOrderRepositoryException("UpdateRepairOrder", ex); }
        }

    }

}
