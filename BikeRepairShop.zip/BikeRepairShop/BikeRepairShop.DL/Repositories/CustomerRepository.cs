﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Factories;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.DL.Exceptions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.DL.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private string connectionString;
        public CustomerRepository(string connectionString)
        {
            this.connectionString = connectionString;
        }
        //BIKE
        public void AddBike(Bike bike)
        {
            try
            {
                string sql = "INSERT INTO dbo.bike(BikeType,Purchasecost,Description,Customer_Id,Status) output INSERTED.ID VALUES(@biketype,@purchasecost,@description,@customerid,@status)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;

                    command.Parameters.AddWithValue("@biketype", bike.BikeType.ToString());
                    command.Parameters.AddWithValue("@purchasecost", bike.PurchaseCost);

                    if (bike.Description != null)
                    {
                        command.Parameters.AddWithValue("@description", bike.Description);
                    } else
                    {
                        command.Parameters.AddWithValue("@description", DBNull.Value);
                    }

                    command.Parameters.AddWithValue("@customerid", bike.Customer.ID);

                    command.Parameters.AddWithValue("@status", 1);
                    int bid = (int)command.ExecuteScalar();
                    bike.SetId(bid);
                }   
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("AddBike", ex);
            }
        }
        public void DeleteBike(Bike bike)
        {
            try
            {
                string sqlDel = "UPDATE dbo.Bike SET Status=0 WHERE Description=@description and PurchaseCost=@purchasecost and Status=1";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand command = conn.CreateCommand())
                {
                    conn.Open();
                    command.CommandText = sqlDel;
                    command.Parameters.AddWithValue("@description", bike.Description);
                    command.Parameters.AddWithValue("@purchasecost", bike.PurchaseCost);
                    command.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("DeleteBike", ex);
            }
        }
        public void UpdateBike(Bike bike)
        {
            try
            {
                string sql = "UPDATE dbo.Bike SET BikeType=@biketype,PurchaseCost=@purchasecost,Customer_Id=@customerid,Description=@description WHERE Id=@id and Status=1";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@biketype", bike.BikeType.ToString());
                    command.Parameters.AddWithValue("@purchasecost", bike.PurchaseCost);
                    if (bike.Description != null) command.Parameters.AddWithValue("@description", bike.Description);
                    else command.Parameters.AddWithValue("@description", DBNull.Value);
                    command.Parameters.AddWithValue("@customerid", bike.Customer.ID);
                    command.Parameters.AddWithValue("@id", bike.ID);
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("UpdateBike", ex); }
        }
        public List<BikeInfo> GetBikesInfo()
        {
            try
            {
                List<BikeInfo> bikes = new List<BikeInfo>();
                string sql = "SELECT t1.*, t2.Name, t2.Email FROM Bike t1 inner join Customer t2 ON t1.Customer_Id = t2.Id" +
                    " WHERE t1.status = 1 AND t2.status = 1";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    IDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        //string d=reader.IsDBNull(reader.GetOrdinal("Description")) ? null : (string)reader["Description"];
                        //Enum.Parse(typeof(BikeType), (string)reader["BikeType"], true);

                        bikes.Add(new BikeInfo((int)reader["id"],
                            reader.IsDBNull(reader.GetOrdinal("Description")) ? null : (string)reader["Description"], //kijken of er een null waaerde is
                            (BikeType)Enum.Parse(typeof(BikeType), (string)reader["BikeType"], true),
                            (double)reader["PurchaseCost"],
                            (int)reader["Customer_Id"],
                            (string)reader["Name"] + " (" + (string)reader["Email"] + ")"));
                    }
                    reader.Close();
                }
                return bikes;
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetBikesInfo", ex); }

        }
        public int GetBikeNumber()
        {
            int number = 0;
            string sql = "SELECT TOP 1 Id FROM dbo.Bike ORDER BY Id DESC";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;

                int output = (int)command.ExecuteScalar();
                output = output + 1;
                return output;
            } 
        }
        public ObservableCollection<string> GetAllBikesFromCustomer(int id)
        {
            string sql = "SELECT Description" +
                         " FROM dbo.Bike" +
                         " WHERE Status = 1 AND Customer_Id = @customerid";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;
                command.Parameters.AddWithValue("@customerid", id);
                IDataReader reader = command.ExecuteReader();

                string description = "";
                ObservableCollection<string> bikes = new ObservableCollection<string>();

                while (reader.Read())
                {
                    description = (string)reader["Description"];
                    bikes.Add(description);
                }
                reader.Close();
                return bikes;
            }
        }
        //CUSTOMER
        public void AddCustomer(Customer customer)
        {
            try
            {
                string sqlC = "INSERT INTO dbo.customer(name,email,address,status) output INSERTED.ID VALUES(@name,@email,@address,@status)";
                string sqlB = "INSERT INTO dbo.bike(biketype,purchasecost,description,customer_id,status) output INSERTED.ID VALUES(@biketype,@purchasecost,@description,@customerid,@status)";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();
                    try
                    {
                        command.Transaction = transaction;
                        command.CommandText = sqlC;
                        command.Parameters.AddWithValue("@name", customer.Name);
                        command.Parameters.AddWithValue("@email", customer.Email);
                        command.Parameters.AddWithValue("@address", customer.Address);
                        command.Parameters.AddWithValue("@status", 1);
                        int id = (int)command.ExecuteScalar();
                        customer.SetId(id);
                        command.CommandText = sqlB;
                        foreach (Bike b in customer.Bikes())
                        {
                            command.Parameters.Clear();
                            command.Parameters.AddWithValue("@biketype", b.BikeType.ToString());
                            command.Parameters.AddWithValue("@purchasecost", b.PurchaseCost);
                            if (b.Description != null) command.Parameters.AddWithValue("@description", b.Description);
                            else command.Parameters.AddWithValue("@description", DBNull.Value);
                            command.Parameters.AddWithValue("@customerid", id);
                            command.Parameters.AddWithValue("@status", 1);

                            int bid = (int)command.ExecuteScalar();
                            b.SetId(bid);
                        }
                        transaction.Commit();
                    }
                    catch (Exception) { transaction.Rollback(); throw; }
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("AddCustomer", ex); }
        }
        public void DeleteCustomer(Customer customer)
        {
            try
            {
                string sqlDel = "UPDATE dbo.customer SET status=0 WHERE email=@email and status=1";
                using (SqlConnection conn = new SqlConnection(connectionString))
                using (SqlCommand command = conn.CreateCommand())
                {
                    conn.Open();
                    command.CommandText = sqlDel;
                    command.Parameters.AddWithValue("@email", customer.Email);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw new CustomerRepositoryException("DeleteCustomer", ex);
            }
        }
        public void UpdateCustomer(Customer customer)
        {
            try
            {
                string sql = "UPDATE dbo.customer SET name=@name,email=@email,address=@address WHERE id=@id and status=1";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    command.Parameters.AddWithValue("@name", customer.Name);
                    command.Parameters.AddWithValue("@email", customer.Email);
                    command.Parameters.AddWithValue("@address", customer.Address);
                    command.Parameters.AddWithValue("@id", customer.ID);
                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("UpdateCustomer", ex); }
        }
        public ObservableCollection<string> GetCustomers()
        {
            string sql = "SELECT Name FROM dbo.Customer WHERE Status = 1";

            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand sqlCommand = connection.CreateCommand())
            {
                connection.Open();
                sqlCommand.CommandText = sql;
                IDataReader reader = sqlCommand.ExecuteReader();

                string name = "";
                ObservableCollection<string> customers = new ObservableCollection<string>();

                while (reader.Read())
                {
                    name = (string)reader["Name"];
                    customers.Add(name);
                }
                reader.Close();
                return customers;
            }
        }
        public Customer GetCustomer(int id)
        {
            try
            {
                string sql = "SELECT t1.*, t2.Id Id, t2.BikeType, t2.PurchaseCost, t2.Description " +
                    "FROM dbo.Customer t1 left join  (Select * from dbo.Bike where status=1) t2 on t1.id=t2.Customer_Id " +
                    "WHERE t1.id=@id AND t1.Status=1";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    sqlCommand.Parameters.AddWithValue("@id", id);
                    IDataReader reader = sqlCommand.ExecuteReader();

                    string name = "";
                    string email = "";
                    string address = "";
                    bool firstLine = true;
                    List<Bike> bikes = new List<Bike>();

                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            name = (string)reader["Name"];
                            email = (string)reader["Email"];
                            address = (string)reader["Address"];
                        }
                        if (!reader.IsDBNull(reader.GetOrdinal("Id")))
                        {
                            bikes.Add(DomainFactory.ExistingBike((int)reader["Id"], (BikeType)Enum.Parse(typeof(BikeType),
                                (string)reader["BikeType"], true), (double)reader["PurchaseCost"],
                                reader.IsDBNull(reader.GetOrdinal("Description")) ? null : (string)reader["Description"]));
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingCustomer(id, name, email, address, bikes);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetCustomer", ex); }
        }
        public Customer GetCustomerWithoutBikes(int id)
        {
            try
            {
                string sql = "SELECT * FROM dbo.Customer WHERE Id = @id and Status = 1";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    sqlCommand.Parameters.AddWithValue("@id", id);
                    IDataReader reader = sqlCommand.ExecuteReader();

                    string name = "";
                    string email = "";
                    string address = "";
                    bool firstLine = true;

                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            name = (string)reader["Name"];
                            email = (string)reader["Email"];
                            address = (string)reader["Address"];
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingCustomerWithoutBikes(id, name, email, address);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetCustomer", ex); }
        }
        public Customer GetCustomer(string email)
        {
            try
            {
                string sqlC = "SELECT t1.*,t2.id bikeid,t2.biketype,t2.purchasecost,t2.description FROM customer t1 left join  (select * from bike where status=1) t2 on t1.id=t2.customerid WHERE t1.email=@email AND t1.status=1 ";
                string sqlROI = "SELECT * from repairorder WHERE customerid=@customerid and status=1";
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sqlC;
                    command.Parameters.AddWithValue("@email", email);
                    IDataReader reader = command.ExecuteReader();
                    string name = null, address = null;
                    int customerid = 0;
                    bool firstLine = true;
                    List<Bike> bikes = new List<Bike>();
                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            name = (string)reader["name"];
                            address = (string)reader["address"];
                            customerid = (int)reader["id"];
                        }
                        if (!reader.IsDBNull(reader.GetOrdinal("bikeid")))
                        {
                            bikes.Add(DomainFactory.ExistingBike((int)reader["bikeid"], (BikeType)Enum.Parse(typeof(BikeType), (string)reader["biketype"], true), (double)reader["purchasecost"],
                               reader.IsDBNull(reader.GetOrdinal("description")) ? null : (string)reader["description"]));
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingCustomer(customerid, name, email, address, bikes);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetCustomer", ex); }
        }
        public List<CustomerInfo> GetCustomersInfo(string? name = null)
        {
            try
            {
                string sql;
                if (name == null)
                    sql = "SELECT t1.id,t1.name,t1.email,t1.address,count(t2.id) nrofbikes,coalesce(sum(t2.purchasecost),0) totalcost "
                     + " FROM dbo.customer t1 left join (select * from bike where status=1) t2 on t1.id=t2.customer_Id "
                     + " WHERE t1.status=1 "
                     + " group by t1.id,t1.name,t1.email,t1.address";
                else
                    sql = "SELECT t1.id,t1.name,t1.email,t1.address,count(t2.id) nrofbikes,coalesce(sum(t2.purchasecost),0) totalcost "
                    + " FROM customer t1 left join (select * from bike where status=1) t2 on t1.id=t2.customer_Id "
                    + " WHERE t1.status=1 AND t1.name LIKE @namematch "
                    + " group by t1.id,t1.name,t1.email,t1.address";

                List<CustomerInfo> customers = new List<CustomerInfo>();
                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand command = connection.CreateCommand())
                {
                    connection.Open();
                    command.CommandText = sql;
                    if (name != null) command.Parameters.AddWithValue("@namematch", $"%{name}%");
                    IDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        customers.Add(new CustomerInfo((int)reader["id"], (string)reader["name"], (string)reader["email"], (string)reader["address"], (int)reader["nrofbikes"], (double)reader["totalcost"]));
                    }
                    reader.Close();
                    return customers;
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetCustomersInfo", ex); }
        }
        public int GetCustomerId(string name)
        {
            string sql = "SELECT Id FROM dbo.Customer WHERE Name=@name";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;
                command.Parameters.AddWithValue("@name", name);
                IDataReader reader = command.ExecuteReader();
                int customerid = 0;
                while (reader.Read())
                {
                  customerid = (int)reader["Id"];
                }
                reader.Close();
                return customerid;
            }

           

        }
        public int GetNextCustomerID()
        {
            int number = 0;
            string sql = "SELECT TOP 1 Id FROM dbo.Customer ORDER BY Id DESC";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;

                int output = (int)command.ExecuteScalar();
                output = output + 1;
                return output;
            }
        }
        public int GetNumberOfBikes(string customerId)
        {
            string sql = "SELECT COUNT(Id) FROM dbo.Bike WHERE Customer_Id = @customerid";
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = connection.CreateCommand())
            {
                connection.Open();
                command.CommandText = sql;
                command.Parameters.AddWithValue("@customerid", customerId);

                int nrofbikes = (int)command.ExecuteScalar();
                return nrofbikes;
            }
        }
        public Customer GetCustomerInfoByName(string name)
        {
            try
            {
                string sql = "SELECT * FROM dbo.Customer WHERE Name = @name and Status = 1";

                using (SqlConnection connection = new SqlConnection(connectionString))
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    connection.Open();
                    sqlCommand.CommandText = sql;
                    sqlCommand.Parameters.AddWithValue("@name", name);
                    IDataReader reader = sqlCommand.ExecuteReader();

                    int id  = 0;
                    string email = "";
                    string address = "";
                    bool firstLine = true;

                    while (reader.Read())
                    {
                        if (firstLine)
                        {
                            firstLine = false;
                            id = (int)reader["Id"];
                            email = (string)reader["Email"];
                            address = (string)reader["Address"];
                        }
                    }
                    reader.Close();
                    return DomainFactory.ExistingCustomerInfoByName(id, name, email, address);
                }
            }
            catch (Exception ex) { throw new CustomerRepositoryException("GetCustomerInfoByName", ex); }
        }
    }
}
