﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.DL.Exceptions
{
    public class RepairmanRepositoryException : Exception
    {
        public RepairmanRepositoryException(string? message) : base(message)
        {
        }

        public RepairmanRepositoryException(string? message, Exception? innerException) : base(message, innerException)
        {
        }
    }
}
