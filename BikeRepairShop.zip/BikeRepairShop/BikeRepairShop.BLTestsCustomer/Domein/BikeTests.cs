﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.Exceptions;
using Xunit;

namespace BikeRepairShop.BL.Domein.Tests
{
    public class BikeTests
    { 
        private Bike _bike;

        public BikeTests()
        {
            _bike = new Bike(BikeType.childBike, 150, "Red");
        }

        [Theory]
        [InlineData(-1)]
        public void SetIdTest_ThrowDomainException(int id)
        {
            Xunit.Assert.Throws<DomainException>(() => _bike.SetId(id));
        }

        [Theory]
        [InlineData(1)]
        public void SetIdTest(int id)
        {
            _bike.SetId(id);
        }

        [Theory]
        [InlineData(1)]
        public void SetId_ThrowsDomainException_ID_Already_Set(int id)
        {
            _bike.SetId(id);
            Xunit.Assert.Throws<DomainException>(() => { _bike.SetId(id); });
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void SetPurchaseCostTest_ThrowDomainException(double cost)
        {
            Xunit.Assert.Throws<DomainException>(() => _bike.SetPurchaseCost(cost));
        }


        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        public void SetPurchaseCostTest(double cost)
        {
            _bike.SetPurchaseCost(cost);
        }
    }
}