﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.Exceptions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using static System.Collections.Specialized.BitVector32;

namespace BikeRepairShop.BLTestsCustomer.Domein
{
    [TestClass()]
    public class RepairTaskTest
    {   
        private RepairTask _repairTask;
        private RepairAction _repairAction;
        private Repairman _repairman;

        [TestInitialize]
        public void Initializer()
        {
            _repairman = new Repairman(1, "Joost", 25, "joost@bike.com");
            _repairAction = new RepairAction(1, "Change brakes", 45, 36.50);
            _repairTask = new(_repairAction, _repairman);
        }

        [TestMethod()]
        [DataRow(-1)]
        [DataRow(0)]
        public void SetIdTestNegative_ThrowsDomainException(int id)
        {
            Assert.ThrowsException<DomainException>(() => { _repairTask.SetId(id); });

        }

        [TestMethod()]
        [DataRow(1)]
        public void SetIdTest_ThrowsDomainException_ID_Already_Set(int id)
        {
            //de exception wordt al gegooid voor een id geset wordt??
            _repairTask.SetId(id);
            Assert.ThrowsException<DomainException>(() => { _repairTask.SetId(id); });
        }

        [TestMethod()]
        [DataRow(1)]
        [DataRow(2)]
        public void SetIdTest(int id)
        {
            //hierdoor komt hier ook dezelfde exception
            //Nu is het gefixt door een '?' toe te voegen aan de int Id, kan ook gefixt worden met een (id <= 0)
            _repairTask.SetId(id);
        }

    }
}
