﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.Exceptions;

namespace BikeRepairShop.BL.Domein.Tests
{
    [TestClass()]
    public class RepairTests
    {
        private RepairTask _task;
        private RepairAction _action;
        private Repairman _repairman;
        private Bike _bike;
        private Repair _repair;

        [TestInitialize]
        public void initializer()
        {
            _repairman = new Repairman(1, "Joost", 25, "joost@bike.com");
            _action = new RepairAction(1, "Change brakes", 45, 36.50);
            _task = new RepairTask(1, _action, _repairman);
            _bike = new Bike(BikeType.regularBike, 75, "red");
            _repair = new(_bike);
        }

        [TestMethod()]
        public void AddRepairTaskTest_ThrowsDomainException()
        {
            var repair = new Repair(_bike);
            repair.AddRepairTask(_task);
            Assert.ThrowsException<DomainException>(() => repair.AddRepairTask(_task));
        }

        [TestMethod()]
        public void AddRepairTaskTest()
        {
            var repair = new Repair(_bike);

            repair.AddRepairTask(_task);

        }

        [TestMethod()]
        public void RemoveRepairTaskTest_ThrowsDomainException()
        {
            var repair = new Repair(_bike);

            Assert.ThrowsException<DomainException>(() => { repair.RemoveRepairTask(_task); });
        }

        [TestMethod()]
        public void RemoveRepairTaskTest()
        {
            var repair = new Repair(_bike);
            repair.AddRepairTask(_task);
            repair.RemoveRepairTask(_task);
        }

        [TestMethod()]
        [DataRow(-1)]
        [DataRow(0)]
        public void SetId_ThrowsDomainException(int id)
        {
            Assert.ThrowsException<DomainException>(() => {  _repair.SetId(id); });
        }

        [TestMethod()]
        [DataRow(1)]
        public void SetId_ThrowsDomainException_ID_Already_Set(int id)
        {
            _repair.SetId(id);
            Assert.ThrowsException<DomainException>(() => { _repair.SetId(id); });
        }

        [TestMethod()]
        [DataRow(1)]
        [DataRow(2)]
        public void SetIdTest(int id)
        {
            _repair.SetId(id);
        }
    }
}