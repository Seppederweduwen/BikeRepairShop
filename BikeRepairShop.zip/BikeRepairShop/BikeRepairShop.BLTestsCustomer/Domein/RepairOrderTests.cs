﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;
using System.Collections;
using BikeRepairShop.BL.Exceptions;
using Xunit;

namespace BikeRepairShop.BL.Domein.Tests
{
    public class RepairOrderTests

    {
        private RepairOrder _repairOrder;
        private Customer _customer;
        private DateOnly _dateIn;
        private DateOnly _dateOut;
        private double _discount;
        private bool _payed;
        private double _costPayed;
        private Urgency _urgency;
        private Repair _repair;

        public RepairOrderTests()
        {
            _repairOrder = new RepairOrder(_dateIn, _dateOut, _customer, _discount, _payed, _costPayed, _urgency);
        }

        [Fact]
        public void AddRepairTest()
        {
            _repair = new Repair(new Bike(BikeType.regularBike, 75, "red"));
            _repairOrder.AddRepair(_repair);
        }

        [Fact]
        public void AddRepairTestNull_ThrowsDomainException()
        {
            Xunit.Assert.Throws<DomainException>(() => _repairOrder.AddRepair(_repair));
        }

        [Fact]
        public void AddRepairTestContains_ThrowsDomainException()
        {
            _repair = new Repair(new Bike(BikeType.regularBike, 75, "red"));
            _repairOrder.AddRepair(_repair);
            Xunit.Assert.Throws<DomainException>(() => _repairOrder.AddRepair(_repair));

        }

        [Fact]
        public void RemoveRepairTest()
        {
            _repair = new Repair(new Bike(BikeType.regularBike, 75, "red"));
            _repairOrder.AddRepair(_repair);
            _repairOrder.RemoveRepair(_repair);
        }

        [Fact]
        public void RemoveRepairTestNull_ThrowsDomainException()
        {
            Xunit.Assert.Throws<DomainException>(() => _repairOrder.RemoveRepair(_repair));
        }

        [Fact]
        public void RemoveRepairTestContains_ThrowsDomainException()
        {
            _repair = new Repair(new Bike(BikeType.regularBike, 75, "red"));
            Xunit.Assert.Throws<DomainException>(() => _repairOrder.RemoveRepair(_repair));

        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        public void SetIdTest(int id)
        {
            _repairOrder.SetId(id);
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void SetIdTest_ThrowsDomainException(int id)
        {
            Xunit.Assert.Throws<DomainException>(() => _repairOrder.SetId(id));
        }

        [Theory]
        [InlineData(1)]
        public void SetId_ThrowsDomainException_ID_Already_Set(int id)
        {
            _repairOrder.SetId(id);
            Xunit.Assert.Throws<DomainException>(() => { _repairOrder.SetId(id); });
        }
    }
    }