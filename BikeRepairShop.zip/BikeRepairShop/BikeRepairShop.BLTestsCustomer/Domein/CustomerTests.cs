﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.Exceptions;
using Xunit;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Factories;

namespace BikeRepairShop.BL.Domein.Tests
{
    public class CustomerTests
    {
        private Customer _customer;
        
        public CustomerTests()
        {
            _customer = new Customer("Jos", "jos@gmail.com", "Gent ");
        }

        [Fact] // 1 waarde testen
        public void Test_constructor_Valid()
        {
            Customer c = new Customer("jos", "jos@gmail", "9000 Gent");
            Xunit.Assert.NotNull(c);
            Xunit.Assert.Equal("jos", c.Name);
            Xunit.Assert.Equal("jos@gmail", c.Email);
            Xunit.Assert.Equal("9000 Gent", c.Address);
        }

        [Theory]
        [InlineData("", "jos@gmail", "Gent")]
        [InlineData("   ", "jos@gmail", "Gent")]
        [InlineData(null, "jos@gmail", "Gent")]
        [InlineData("jos", "", "Gent")]
        [InlineData("jos", "   ", "Gent")]
        [InlineData("jos", null, "Gent")]
        [InlineData("jos", "jos@gmail", "")]
        [InlineData("jos", "jos@gmail", "   ")]
        [InlineData("jos", "jos@gmail", null)]
        public void Test_constructor_Invalid(string name, string email, string address)
        {
            Xunit.Assert.Throws<DomainException>(() => new Customer(name, email, address));
        }

        [Fact]
        public void AddBikeTest_ThrowDomainException()
        {
            var bike = new Bike(BikeType.childBike, 150, "Red");
            
            _customer.AddBike(bike);
            Xunit.Assert.Throws<DomainException>(() => _customer.AddBike(bike)); 
        }

        [Fact]
        public void AddBikeTest()
        {

            Bike bike1 = DomainFactory.NewBike(new BikeInfo(null, "blue bike", BikeType.regularBike, 10, 250, "jos (jos@gmail)"));
            Bike bike2 = DomainFactory.NewBike(new BikeInfo(null, "green bike", BikeType.regularBike, 10, 275, "jos (jos@gmail)"));
            //Customer c = new Customer("jos", "jost@gmail", "9000 Gent");

            Xunit.Assert.Empty(_customer.bikes);
            _customer.AddBike(bike1);
            Xunit.Assert.Contains(bike1, _customer.bikes);
            Xunit.Assert.Single(_customer.bikes);
            Xunit.Assert.Equal(_customer, bike1.Customer);

            _customer.AddBike(bike2);
            Xunit.Assert.Contains(bike1, _customer.bikes);
            Xunit.Assert.Contains(bike2, _customer.bikes);
            Xunit.Assert.True(_customer.bikes.Count == 2);
            Xunit.Assert.Equal(_customer, bike1.Customer);
            Xunit.Assert.Equal(_customer, bike2.Customer);
        }

        [Fact]
        public void AddBikeTest_ThrowDomainException_Null()
        {
            Xunit.Assert.Throws<DomainException>(() => _customer.AddBike(null));
        }

        [Fact]
        public void AddBikeTest_ThrowDomainException_Duplicate()
        {
            Bike bike1 = DomainFactory.NewBike(new BikeInfo(null, "blue bike", BikeType.regularBike, 10, 250, "jos (jos@gmail)"));
            Bike bike2 = DomainFactory.NewBike(new BikeInfo(null, "blue bike", BikeType.regularBike, 10, 250, "jos (jos@gmail)"));
            Xunit.Assert.Empty(_customer.bikes);
            _customer.AddBike(bike1);
            Xunit.Assert.Throws<DomainException>(() => _customer.AddBike(bike2));
            Xunit.Assert.Single(_customer.bikes);
            Xunit.Assert.Contains(bike1, _customer.bikes);
        }

        [Fact]
        public void RemoveBikeTest_ThrowDomainException()
        {
            var bike = new Bike(BikeType.childBike, 150, "Red");

            Xunit.Assert.Throws<DomainException>(() => _customer.RemoveBike(bike));
        }

        [Fact]
        public void RemoveBikeTest()
        {
            var bike = new Bike(BikeType.childBike, 150, "Red");
            _customer.AddBike(bike);
            _customer.RemoveBike(bike);
        }

        [Theory]
        [InlineData("   ")]
        [InlineData(null)]
        public void SetNameTest_ThrowDomainException(string name)
        {
            Xunit.Assert.Throws<DomainException>(() => _customer.SetName(name));
        }

        [Fact]
        public void SetNameTest()
        {
            _customer.SetName("test");
        }

        [Theory]
        [InlineData("   ")]
        [InlineData(null)]
        public void SetEmailTest_ThrowDomainException(string email)
        {
            Xunit.Assert.Throws<DomainException>(() => _customer.SetEmail(email));
        }

        [Fact]
        public void SetEmailTest()
        {
            _customer.SetEmail("test@test.be");
        }

        [Theory]
        [InlineData("   ")]
        [InlineData(null)]
        public void SetAddressTest_ThrowDomainException(string address)
        {
            Xunit.Assert.Throws<DomainException>(() => _customer.SetAddress(address));
        }

        [Fact]
        public void SetAddressTest()
        {
            _customer.SetAddress("test 123");

        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        public void SetIdTest(int id)
        {
            _customer.SetId(id);
        }

        [Theory]
        [InlineData(1)]
        public void SetId_ThrowsDomainException_ID_Already_Set(int id)
        {
            _customer.SetId(id);
            Xunit.Assert.Throws<DomainException>(() => { _customer.SetId(id); });
        }

        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        public void SetId_ThrowsDomainException(int id)
        {
            Xunit.Assert.Throws<DomainException>(() => { _customer.SetId(id); });
        }
    }
}