﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Mappers;
using BikeRepairShop.UI.Admin.Model;
using MongoDB.Driver.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BikeRepairShop.UIAdmin
{
    /// <summary>
    /// Interaction logic for WindowRepairman.xaml
    /// </summary>
    public partial class WindowRepairman : Window
    {
        public RepairmanUI Repairman { get; set; }
        private bool update;
        private RepairmanManager repairmanManager;
        RepairmanRepository repairmanRepository;
        string connectionString;

        public WindowRepairman(RepairmanManager repairmanManager ,bool update = false)
        {
            InitializeComponent();
            this.repairmanManager = repairmanManager;

            connectionString = Convert.ToString(ConfigurationManager.ConnectionStrings[1]);
            repairmanRepository = new RepairmanRepository(connectionString);

            this.update = update;

            if (update)
            {

            }
            else
            {
                IdTextBox.Text = Convert.ToString(repairmanRepository.GetNextId());
            }
        }
        public void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        public void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                if (string.IsNullOrWhiteSpace(IdTextBox.Text) || string.IsNullOrWhiteSpace(NameTextBox.Text) || string.IsNullOrWhiteSpace(CostPerHourTextBox.Text) || string.IsNullOrWhiteSpace(EmailTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.", "Empty Fields");
                    return;
                }

                Repairman.Id = Convert.ToInt32(IdTextBox.Text);
                Repairman.Name = NameTextBox.Text;
                Repairman.CostPerHour = Convert.ToInt32(CostPerHourTextBox.Text);
                Repairman.Email = EmailTextBox.Text;
                

                RepairmanInfo RepairmanInfo = new RepairmanInfo(Repairman.Id, Repairman.Name, Repairman.CostPerHour, Repairman.Email);
                repairmanManager.UpdateRepairman(RepairmanInfo);
            }
            else
            {
                if (string.IsNullOrWhiteSpace(IdTextBox.Text) || string.IsNullOrWhiteSpace(NameTextBox.Text) || string.IsNullOrWhiteSpace(CostPerHourTextBox.Text) || string.IsNullOrWhiteSpace(EmailTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.", "Empty Fields");
                    return;
                }

                Repairman = new RepairmanUI(Convert.ToInt32(IdTextBox.Text), NameTextBox.Text, Convert.ToInt32(CostPerHourTextBox.Text), EmailTextBox.Text);
                repairmanManager.AddRepairman(RepairmanMapper.ToDTO(Repairman));
            }

            DialogResult = true;
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                IdTextBox.Text = Convert.ToString(Repairman.Id);
                NameTextBox.Text = Repairman.Name;
                CostPerHourTextBox.Text= Convert.ToString(Repairman.CostPerHour);
                EmailTextBox.Text = Repairman.Email;
            }

        }
    }
}
