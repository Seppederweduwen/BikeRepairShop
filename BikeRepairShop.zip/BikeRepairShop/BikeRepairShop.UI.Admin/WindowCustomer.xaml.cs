﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Mappers;
using BikeRepairShop.UI.Admin.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BikeRepairShop.UIAdmin
{
    /// <summary>
    /// Interaction logic for WindowCustomer.xaml
    /// </summary>
    public partial class WindowCustomer : Window
    {
        public CustomerUI Customer { get; set; }
        private bool update;
        private CustomerManager customerManager;
        string connectionString;
        CustomerRepository customerRepository;

        public WindowCustomer(CustomerManager customerManager ,bool update = false)
        {
            InitializeComponent();
            this.customerManager = customerManager;

            connectionString = Convert.ToString(ConfigurationManager.ConnectionStrings[1]);
            customerRepository = new CustomerRepository(connectionString);

            this.update = update;

            if (update)
            {
                
            }
            else
            {
                IdTextBox.Text = Convert.ToString(customerRepository.GetNextCustomerID());
            }
        }

        public void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        public void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                if (string.IsNullOrWhiteSpace(NameTextBox.Text) || string.IsNullOrWhiteSpace(EmailTextBox.Text) || string.IsNullOrWhiteSpace(AddressTextBox.Text) || string.IsNullOrWhiteSpace(BikesTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.", "Empty Fields");
                    return;
                }

                Customer.Name = NameTextBox.Text;
                Customer.Email = EmailTextBox.Text;
                Customer.Address = AddressTextBox.Text;
                Customer.NrOfBikes = Convert.ToInt32(BikesTextBox.Text);

                CustomerInfo customerInfo = new CustomerInfo(Customer.Id, Customer.Name, Customer.Email, Customer.Address, Customer.NrOfBikes, Customer.TotalBikesValue);

                if(customerInfo.NrOfBikes == 0)
                {
                    customerManager.UpdateCustomerWithoutBikes(customerInfo);
                }
                else
                {
                    customerManager.UpdateCustomer(customerInfo);
                }
            }
            else
            {
                if (string.IsNullOrWhiteSpace(NameTextBox.Text) || string.IsNullOrWhiteSpace(EmailTextBox.Text) || string.IsNullOrWhiteSpace(AddressTextBox.Text) || string.IsNullOrWhiteSpace(BikesTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.", "Empty Fields");
                    return;
                }

                Customer = new CustomerUI(Convert.ToInt32(IdTextBox.Text), NameTextBox.Text, EmailTextBox.Text, AddressTextBox.Text, Convert.ToInt32(BikesTextBox.Text), 0);
                customerManager.AddCustomer(CustomerMapper.ToDTO(Customer));
            }

            DialogResult = true;
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                IdTextBox.Text = Convert.ToString(Customer.Id);
                NameTextBox.Text = Customer.Name;
                AddressTextBox.Text = Customer.Address;
                EmailTextBox.Text = Customer.Email;
                BikesTextBox.Text = Convert.ToString(Customer.NrOfBikes);
            }
        }
    }
}
