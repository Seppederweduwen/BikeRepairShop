﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Model;
using BikeRepairShop.UIAdmin;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Linq;
using System.Windows;

namespace BikeRepairShop.UI.Admin
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<BikeUI> bikes;
        private CustomerManager customerManager;
        private RepairmanManager repairmanManager;
        private RepairorderManager repairorderManager;
        private ICustomerRepository customerRepo;
        private IRepairmanRepository repairmanRepo;
        private IRepairOrderRepository repairorderRepo;
        private ObservableCollection<string> customers;
        private ObservableCollection<CustomerUI> customers1;
        private ObservableCollection<RepairmanUI> repairmen;
        private ObservableCollection<string> repairmen1;
        private ObservableCollection<string> repairtasks;
        private ObservableCollection<RepairOrderUI> AllRepairOrders;
        public MainWindow()
        {
            InitializeComponent();
            string connString = ConfigurationManager.ConnectionStrings["ADOconnSQL"].ConnectionString;

            customerRepo = new CustomerRepository(connString);
            customerManager = new CustomerManager(customerRepo);

            repairmanRepo = new RepairmanRepository(connString);
            repairmanManager = new RepairmanManager(repairmanRepo);

            repairorderRepo = new RepairOrderRepository(connString);
            repairorderManager = new RepairorderManager(repairorderRepo);

            bikes = new ObservableCollection<BikeUI>(customerManager.GetBikeInfos().Select(x => new BikeUI(x.ID, x.Description, x.BikeType, x.PurchaseCost, x.Customer.id, x.Customer.description)));


            List<string> Namen = new List<string>();
            customers = (customerRepo.GetCustomers());
            customers1 = new ObservableCollection<CustomerUI>(customerManager.GetCustomersInfo().Select(y => new CustomerUI(y.ID, y.Name, y.Email, y.Address, y.NrOfBikes, y.TotalBikesValue)));

            repairmen1 = (repairmanRepo.GetRepairMen());
            repairmen = new ObservableCollection<RepairmanUI>(repairmanManager.GetRepairmenInfo().Select(z => new RepairmanUI(z.ID, z.Name, z.CostPerHour, z.Email)));

            AllRepairOrders = new ObservableCollection<RepairOrderUI>(repairorderManager.GetRepairOrderInfo().Select(x => new RepairOrderUI(x.CustomerId, x.RepairOrderId, x.DateIn, x.DateOut, x.Cost, x.Discount, x.Urgency, x.Payed)));

            repairtasks = (repairorderRepo.GetRepairActions());


            BikeDataGrid.ItemsSource = bikes;
            BikeDataGrid.IsReadOnly = true;
            CustomerDataGrid.ItemsSource = customers1;
            CustomerDataGrid.IsReadOnly = true;
            RepairmanDataGrid.ItemsSource = repairmen;
            RepairmanDataGrid.IsReadOnly = true;
            RepairOrderDataGrid.ItemsSource = AllRepairOrders;
            RepairOrderDataGrid.IsReadOnly = true;
        }
        #region BIKES
        private void MenuItemAddBike_Click(object sender, RoutedEventArgs e)
        {
            WindowBike windowBike = new WindowBike(customerManager);
            windowBike.CustomerComboBox.ItemsSource = customers;
            windowBike.CustomerComboBox.SelectedIndex = 0;
            if (windowBike.ShowDialog() == true) //Je moet het venster eerst sluiten voor met een ander kan bezig zijn (show dialog)
            {
                bikes.Add(windowBike.Bike);
            }
        }
        private void MenuItemDeleteBike_Click(object sender, RoutedEventArgs args)
        {
            BikeUI bikeui = (BikeUI)BikeDataGrid.SelectedItem;
            Bike bike = new Bike(bikeui.BikeType, bikeui.PurchaseCost, bikeui.Description);

            if (bike == null)
            {
                MessageBox.Show("No selection", "Bike");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Bike", System.Windows.MessageBoxButton.YesNo);


                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    bikes.Remove(bikeui);
                    customerRepo.DeleteBike(bike);
                }
            }
        }
        private void MenuItemUpdateBike_Click(object sender, RoutedEventArgs args)
        {
            BikeUI bike = (BikeUI)BikeDataGrid.SelectedItem;
            if (bike == null)
            {
                MessageBox.Show("No selection", "Bike");
            }
            else
            {
                WindowBike w = new WindowBike(customerManager, true);
                w.Bike = bike;
                w.ShowDialog();
            }
        }
        #endregion
        #region CUSTOMER
        //CUSTOMER
        private void MenuItemAddCustomer_Click(object sender, RoutedEventArgs e)
        {
            WindowCustomer windowCustomer = new WindowCustomer(customerManager);
            if (windowCustomer.ShowDialog() == true)
            {
                customers.Add(Convert.ToString(windowCustomer.Customer));
                customers1.Add(windowCustomer.Customer);
            };
        }
        private void MenuItemDeleteCustomer_Click(object sender, RoutedEventArgs e)
        {
            CustomerUI customerui = (CustomerUI)CustomerDataGrid.SelectedItem;
            Customer customer = new Customer(customerui.Name, customerui.Email, customerui.Address);
            if (customer == null)
            {
                MessageBox.Show("No selection", "Customer");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Customer", System.Windows.MessageBoxButton.YesNo);

                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    customers1.Remove(customerui);
                    customerRepo.DeleteCustomer(customer);
                }
            }
        }
        private void MenuItemUpdateCustomer_Click(object sender, RoutedEventArgs e)
        {
            CustomerUI customer = (CustomerUI)CustomerDataGrid.SelectedItem;
            if (customer == null)
            {
                MessageBox.Show("No selection", "Customer");
            }
            else
            {
                WindowCustomer w = new WindowCustomer(customerManager, true);
                w.Customer = customer;
                w.ShowDialog();
            }
        }
        #endregion
        #region REPAIRMEN
        private void MenuItemAddRepairman_Click(object sender, RoutedEventArgs e)
        {
            WindowRepairman windowRepairman = new WindowRepairman(repairmanManager);
            if (windowRepairman.ShowDialog() == true)
            {
                repairmen.Add(windowRepairman.Repairman);
            }
        }

        private void MenuItemDeleteRepairman_Click(object sender, RoutedEventArgs e)
        {

            RepairmanUI repairmanui = (RepairmanUI)RepairmanDataGrid.SelectedItem;
            Repairman repairman = new Repairman(repairmanui.Id, repairmanui.Name, Convert.ToInt32(repairmanui.CostPerHour), repairmanui.Email);
            if (repairmanui == null)
            {
                MessageBox.Show("No selection", "Repairman");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Repairman", System.Windows.MessageBoxButton.YesNo);

                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    repairmen.Remove(repairmanui);
                    repairmanRepo.DeleteRepairman(repairman);
                }
            }
        }

        private void MenuItemUpdateRepairman_Click(object sender, RoutedEventArgs e)
        {
            RepairmanUI repairman = (RepairmanUI)RepairmanDataGrid.SelectedItem;
            if (repairman == null)
            {
                MessageBox.Show("No selection", "Repairman");
            }
            else
            {
                WindowRepairman w = new WindowRepairman(repairmanManager, true);
                w.Repairman = repairman;
                w.ShowDialog();
            }
        }
        #endregion
        #region REPAIRORDER
        //REPAIRORDER
        private void MenuItemAddRepairOrder_Click(object sender, RoutedEventArgs e)
        {
            WindowRepairOrder windowRepairOrder = new WindowRepairOrder(repairorderManager, null, null, false);
            windowRepairOrder.CustomerComboBox.ItemsSource = customers1.Select(c => c.Name);
            windowRepairOrder.RepairManComboBox.ItemsSource = repairmen1;
            windowRepairOrder.RepairActionComboBox.ItemsSource = repairtasks;
            if (windowRepairOrder.ShowDialog() == true) //Je moet het venster eerst sluiten voor met een ander kan bezig zijn (show dialog)
            {
                CustomerDataGrid.ItemsSource = AllRepairOrders;
            }
        }
        private void MenuItemDeleteRepairOrder_Click(object sender, RoutedEventArgs e)
        {
            RepairOrderUI repairorderui = (RepairOrderUI)RepairOrderDataGrid.SelectedItem;
            if (repairorderui == null)
            {
                MessageBox.Show("No selection", "Repairman");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Repairman", MessageBoxButton.YesNo);

                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    AllRepairOrders.Remove(repairorderui);
                    repairorderRepo.DeleteRepairOrder(repairorderui.CustomerId, repairorderui.Cost);
                }
            }
        }
        private void MenuItemUpdateRepairOrder_Click(object sender, RoutedEventArgs e)
        {
            RepairOrderUI repairorder = (RepairOrderUI)RepairOrderDataGrid.SelectedItem;
            if (repairorder == null)
            {
                MessageBox.Show("No selection", "Repairman");
            }
            else
            {
                string customerName = repairorderRepo.GetCustomerNameByCustomerId(repairorder.CustomerId);

                List<RepairActionInfo> tasks = repairorderRepo.GetAllRepairActionsByRepairOrderId(repairorder.RepairOrderId);

                WindowRepairOrder w = new WindowRepairOrder(repairorderManager, repairorder, tasks, true);
                w.RepairManComboBox.ItemsSource = repairmen1;
                w.RepairActionComboBox.ItemsSource = repairtasks;

                // Haal de taken op voor de geselecteerde reparatieorder

                // Wijs de lijst met taken toe aan de ItemsSource van de RepairTaskDataGrid
                w.RepairTaskDataGrid.ItemsSource = tasks;

                // Maak een lijst met een enkel item (de geselecteerde klantnaam)
                List<string> customerList = new List<string> { customerName };

                // Wijs de lijst met de enkele klantnaam toe aan de ItemsSource van de CustomerComboBox
                w.CustomerComboBox.ItemsSource = customerList;

                // Selecteer de enkele klantnaam
                w.CustomerComboBox.Text = customerName;

                w.RepairOrder = repairorder;
                w.ShowDialog();
            }
        }
        #endregion
    }
}
