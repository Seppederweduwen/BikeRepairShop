﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Mappers;
using BikeRepairShop.UI.Admin.Model;
using MongoDB.Driver.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BikeRepairShop.UI.Admin
{
    /// <summary>
    /// Interaction logic for WindowBike.xaml
    /// </summary>
    public partial class WindowBike : Window
    {  
        public BikeUI Bike { get; set; }
        private bool update;
        private CustomerManager customerManager;
        string connectionString;
        CustomerRepository customerRepository;

        public WindowBike(CustomerManager customerManager, bool update = false)
        {
            InitializeComponent();
            this.customerManager = customerManager;

            connectionString = Convert.ToString(ConfigurationManager.ConnectionStrings[1]);
            customerRepository = new CustomerRepository(connectionString);


            BikeTypeComboBox.ItemsSource = Enum.GetValues(typeof(BikeType));
            BikeTypeComboBox.SelectedIndex = 0;

            this.update = update;
            
            if (update)
            {
                CustomerTextBox.Visibility = Visibility.Visible;
                CustomerComboBox.Visibility = Visibility.Collapsed;
            }
            else 
            { 
                CustomerTextBox.Visibility = Visibility.Collapsed; 
                CustomerComboBox.Visibility = Visibility.Visible;
            }
        }

        private void CancelBikeButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void SaveBikeButton_Click(object sender, RoutedEventArgs e)
        {

            if (update)
            {
                if (string.IsNullOrEmpty(IdTextBox.Text) ||
                    string.IsNullOrEmpty(DescriptionTextBox.Text) ||
                    BikeTypeComboBox.SelectedItem == null ||
                    string.IsNullOrEmpty(PurchaseCostTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.", "Empty Fields");
                    return;
                }

                Bike.CustomerId = Convert.ToInt32(IdTextBox.Text);
                Bike.Description = DescriptionTextBox.Text;
                Bike.BikeType = (BikeType)BikeTypeComboBox.SelectedItem;
                Bike.PurchaseCost= double.Parse(PurchaseCostTextBox.Text);

                BikeInfo bikeInfo = new BikeInfo(Bike.Id, Bike.Description, Bike.BikeType, Bike.PurchaseCost, Bike.CustomerId, Bike.CustomerDescription);

                customerManager.UpdateBike(bikeInfo);
            }
            else 
            {
                if (string.IsNullOrEmpty(IdTextBox.Text) ||
                string.IsNullOrEmpty(DescriptionTextBox.Text) ||
                BikeTypeComboBox.SelectedItem == null ||
                string.IsNullOrEmpty(PurchaseCostTextBox.Text))
                {
                    MessageBox.Show("Please fill in all fields before updating the bike.","Empty Fields");
                    return;
                }

                if (customerRepository.GetNumberOfBikes(IdTextBox.Text) == 0)
                {
                    int number = customerRepository.GetBikeNumber();
                    Bike = new BikeUI(number, DescriptionTextBox.Text, (BikeType)BikeTypeComboBox.SelectedItem, double.Parse(PurchaseCostTextBox.Text), Convert.ToInt32(IdTextBox.Text), Convert.ToString(CustomerComboBox.SelectedItem));
                    customerManager.AddFirstBike(BikeMapper.ToDTO(Bike));
                }
                else
                {
                    int number = customerRepository.GetBikeNumber();
                    Bike = new BikeUI(number, DescriptionTextBox.Text, (BikeType)BikeTypeComboBox.SelectedItem, double.Parse(PurchaseCostTextBox.Text), Convert.ToInt32(IdTextBox.Text), Convert.ToString(CustomerComboBox.SelectedItem));
                    customerManager.AddBike(BikeMapper.ToDTO(Bike));
                }
            }
           
            DialogResult = true;
            Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                CustomerTextBox.Text = Bike.CustomerDescription;
                BikeTypeComboBox.SelectedItem = Bike.BikeType;
                DescriptionTextBox.Text = Bike.Description;
                IdTextBox.Text = Bike.CustomerId.ToString();
                PurchaseCostTextBox.Text = Bike.PurchaseCost.ToString();
            }
        }

        private void CustomerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string name = CustomerComboBox.SelectedValue.ToString();
            int CustomerId = customerRepository.GetCustomerId(name);
            IdTextBox.Text = Convert.ToString(CustomerId);
        }
    }
}
