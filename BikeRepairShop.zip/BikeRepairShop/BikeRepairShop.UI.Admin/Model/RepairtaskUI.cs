﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Xml.Linq;

namespace BikeRepairShop.UI.Admin.Model
{
    public class RepairtaskUI : INotifyPropertyChanged
    {

        private int? id;
        public int? Id { get { return id; } set { id = value; OnPropertyChanged(); } }

        private int? repairtime;
        public int? repairTime { get { return repairtime; } set { repairtime = value; OnPropertyChanged(); } }

        private string description;
        public string Description { get { return description; } set { description = value; OnPropertyChanged(); } }

        private double costmaterials;
        public double costMaterials { get { return costmaterials; } set { costmaterials = value; OnPropertyChanged(); } }


        public RepairtaskUI(int? id, int? repairTime, string description, double costMaterials)
        {
            Id = id;
            this.repairTime = repairTime;
            Description = description;
            this.costMaterials = costMaterials;
        }

        public RepairtaskUI( int? repairTime, string description, double costMaterials)
        {
            this.repairTime = repairTime;
            Description = description;
            this.costMaterials = costMaterials;
        }


        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string description = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(description));
        }


    }
}
