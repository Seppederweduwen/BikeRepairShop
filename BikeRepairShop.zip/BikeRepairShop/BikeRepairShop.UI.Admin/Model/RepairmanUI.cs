﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.UI.Admin.Model
{
    public class RepairmanUI : INotifyPropertyChanged
    {
        public RepairmanUI(int? id, string name, decimal costPerHour, string email)
        {
            Id = id;
            Name = name;
            CostPerHour = costPerHour;
            Email = email;
        }

        private int? id { get; set; }
        public int? Id { get { return id; } set { id = value; OnPropertyChanged(); } }
        private string name { get; set; }
        public string Name { get { return name; } set { name = value; OnPropertyChanged(); } }
        private decimal costperhour { get; set; }
        public decimal CostPerHour { get { return costperhour; } set { costperhour = value; OnPropertyChanged(); } }
        private string email { get; set; }
        public string Email { get { return email; } set { email = value; OnPropertyChanged(); } }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
