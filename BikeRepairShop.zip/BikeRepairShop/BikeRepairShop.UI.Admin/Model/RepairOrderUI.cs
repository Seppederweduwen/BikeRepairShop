﻿using BikeRepairShop.BL.Domein;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.UI.Admin.Model
{
    public class RepairOrderUI : INotifyPropertyChanged
    {
        private int customerId;
        public int CustomerId { get { return customerId; } set { customerId = value; OnPropertyChanged(); } }

        private DateTime dateIn;
        public DateTime DateIn { get { return dateIn; } set { dateIn = value; OnPropertyChanged(); } }

        private DateTime dateOut;
        public DateTime DateOut { get { return dateOut; } set { dateOut = value; OnPropertyChanged(); } }

        private double cost;
        public double Cost { get { return cost; } set { cost = value; OnPropertyChanged(); } }

        private double discount;
        public double Discount { get { return discount; } set { discount = value; OnPropertyChanged(); } }

        private string urgency;
        public string Urgency { get { return urgency; } set { urgency = value; OnPropertyChanged(); } }

        private int payed;

        public RepairOrderUI(int customerId, DateTime dateIn, DateTime dateOut, double cost, double discount, string urgency,int payed)
        {
            CustomerId = customerId;
            DateIn = dateIn;
            DateOut = dateOut;
            Cost = cost;
            Discount = discount;
            Urgency = urgency;
            Urgency = urgency;
            Payed = payed;
        }

        public int Payed { get { return payed; } set { payed = value; OnPropertyChanged(); } }


        public event PropertyChangedEventHandler? PropertyChanged;

        private void OnPropertyChanged(string description = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(description));
        }

        public override string? ToString()
        {
            return base.ToString();
        }


    }
}
