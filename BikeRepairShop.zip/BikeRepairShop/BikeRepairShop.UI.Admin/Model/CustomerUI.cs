﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace BikeRepairShop.UI.Admin.Model
{
    public class CustomerUI : INotifyPropertyChanged
    {
        public CustomerUI(int? id, string name, string email, string address, int nrofbikes, double totalbikesvalue)
        {
            Id = id;
            Name = name;
            Email = email;
            Address = address;
            NrOfBikes = nrofbikes;
            TotalBikesValue = totalbikesvalue;
        }
        public CustomerUI(string name)
        {
            Name = name;
        }
        private int? id;
        public int? Id { get {  return id; } set { id = value; OnPropertyChanged(); } }
        private string name;
        public string Name { get { return name; } set { name = value; OnPropertyChanged(); } }
        private string email;
        public string Email { get { return email; } set { email = value; OnPropertyChanged(); } }
        private string address;
        public string Address { get { return address; } set { address = value; OnPropertyChanged(); } }
        private int nrOfBikes;
        public int NrOfBikes { get { return nrOfBikes; } set { nrOfBikes = value; OnPropertyChanged(); } }
        private double totalBikesValue;
        public double TotalBikesValue { get { return totalBikesValue; } set { totalBikesValue = value; OnPropertyChanged(); } }
        public string CustomerDescription { get { return $"{Name} ({Email})"; } }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        public override string? ToString()
        {
            return Name;
        }


    }
}
