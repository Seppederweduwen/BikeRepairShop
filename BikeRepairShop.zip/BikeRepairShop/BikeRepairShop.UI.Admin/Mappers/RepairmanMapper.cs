﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.UI.Admin.Model;

namespace BikeRepairShop.UI.Admin.Mappers
{
    public class RepairmanMapper
    {
        public static RepairmanInfo ToDTO(RepairmanUI repairmanUI)
        {
            return new RepairmanInfo(repairmanUI.Id, repairmanUI.Name,  repairmanUI.CostPerHour, repairmanUI.Email);
        }
    }
}
