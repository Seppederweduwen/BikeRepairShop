﻿using BikeRepairShop.BL.DTO;
using BikeRepairShop.UI.Admin.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BikeRepairShop.UI.Admin.Mappers
{
    public class RepairOrderMapper
    {
        public static RepairOrderInfo ToDTO(RepairOrderUI repairorderUI)
        {
            return new RepairOrderInfo(repairorderUI.RepairOrderId, repairorderUI.CustomerId, repairorderUI.DateIn, repairorderUI.DateOut, repairorderUI.Cost, repairorderUI.Discount, repairorderUI.Urgency, repairorderUI.Payed);
        }
    }
}
