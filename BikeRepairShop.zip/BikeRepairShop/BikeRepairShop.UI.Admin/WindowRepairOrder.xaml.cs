﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;

namespace BikeRepairShop.UI.Admin
{
    /// <summary>
    /// Interaction logic for WindowRepairOrder.xaml
    /// </summary>
    public partial class WindowRepairOrder : Window
    {
        private bool update;
        public RepairOrderUI RepairOrder { get; set; }

        private ICustomerRepository customerRepo;
        private IRepairOrderRepository repairOrderRepository;
        private IRepairmanRepository repairmanRepository;
        private RepairorderManager repairorderManager;
        private List<RepairtaskInfo> repairtasks1;
        Repair repair = new Repair();
        ObservableCollection<RepairtaskInfo> repairtaskInfos;
        List<RepairtaskInfo> selectedrepairTasks = new List<RepairtaskInfo>();
        List<int> selectedrepairTasksIds = new List<int>();
        //List<Repair> SelectedRepairTasks1 = new List<Repair>();
        double totalPrice;
        public bool IsSaved = false;
        ObservableCollection<RepairtaskUI> repairTasks = new ObservableCollection<RepairtaskUI>();
        public WindowRepairOrder(RepairorderManager repairOrderManager, bool update = false)
        {
            InitializeComponent();

            this.repairorderManager = repairOrderManager;
            this.update = update;

            string connString = ConfigurationManager.ConnectionStrings["ADOconnSQL"].ConnectionString;
            customerRepo = new CustomerRepository(connString);
            repairOrderRepository = new RepairOrderRepository(connString);
            repairorderManager = new RepairorderManager(repairOrderRepository);
            repairmanRepository = new RepairmanRepository(connString);

            repairtasks1 = repairOrderRepository.GetRepairActionsInfo();
            //CustomerTextBox.Text = repairOrderRepository.GetCustomerNameByCustomerId(repairOrderManager.CustomerId);

        }
        private void CustomerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int CustomerId;
            CustomerId = customerRepo.GetCustomerId(CustomerComboBox.SelectedValue.ToString());
            BikeComboBox.ItemsSource = customerRepo.GetAllBikesFromCustomer(CustomerId);
            CustomerTextBox.Text = CustomerComboBox.SelectedValue.ToString();
        }
        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            string repairAction = RepairActionComboBox.SelectedValue.ToString();
            double costMaterials = 0;
            string repairMan = RepairManComboBox.SelectedValue.ToString();
            string customer = CustomerComboBox.SelectedValue.ToString();
            string bike = BikeComboBox.SelectedValue.ToString();
            int repairOrderId = repairOrderRepository.GetNextRepairOrderId();
            int selectedIndex = 0;

            if (CustomerComboBox.SelectedIndex == -1
                || BikeComboBox.SelectedIndex == -1
                || RepairManComboBox.SelectedIndex == -1
                || RepairActionComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all fields before adding the task.", "Empty Fields");
                return;
            }
                    
            //CODE INVOEREN VOOR HET OPSLAAN VAN DE REPAIRTASK

            int taskId;
            string description = RepairActionComboBox.SelectedValue.ToString();
                 
            //opvragen van nodige info
            costMaterials = repairOrderRepository.GetCostMaterials(description);
            totalPrice += costMaterials;

            taskId = repairOrderRepository.GetTaskId(description);
            selectedrepairTasksIds.Add(taskId);

            selectedIndex = RepairActionComboBox.SelectedIndex;
            selectedrepairTasks.Add(repairtasks1[selectedIndex]);
            repairOrderRepository.SaveRepairTask(repairAction, repairMan, costMaterials, customer, bike, repairOrderId);

            RepairAction repairAction1 = repairOrderRepository.GetRepairActionInfo(Convert.ToString(RepairActionComboBox.SelectedValue));
            Repairman repairman = repairmanRepository.GetRepairman(Convert.ToString(RepairManComboBox.SelectedValue));

            RepairTask repairTask = new RepairTask(repairAction1, repairman);

            repair.AddRepairTask(repairTask);

            //Updaten van de UI
            PriceTextBox.Text = totalPrice.ToString();
            RepairTaskDataGrid.ItemsSource = selectedrepairTasks;
            CustomerComboBox.Visibility = Visibility.Collapsed;
            CustomerTextBox.Visibility = Visibility.Visible;
            RepairActionComboBox.SelectedIndex = -1;

        }
        private void MenuItemDeleteRepairtask_Click(object sender, RoutedEventArgs e)
        {
            if (RepairTaskDataGrid.SelectedIndex == null)
            {
                MessageBox.Show("No selection", "Repairtask");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Repairtask", System.Windows.MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    selectedrepairTasks.RemoveAt(RepairTaskDataGrid.SelectedIndex);
                    selectedrepairTasksIds.RemoveAt(RepairTaskDataGrid.SelectedIndex);
                    RepairTaskDataGrid.ItemsSource = selectedrepairTasks;
                }
            }
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (UrgencyComboBox.SelectedIndex == -1 || DatePickerDateOut.Text == "")
            {
                if (DatePickerDateOut.Text == "")
                {
                    MessageBox.Show("Select a date", "No date selected");
                }
                else
                {
                    MessageBox.Show("Please fill in all the fields", "Empty Urgency");
                }
            }
            else
            {
                if (Convert.ToDateTime(DatePickerDateOut.Text) < DateTime.Now)
                {
                    MessageBox.Show("Dates can not be in the past", "Date in the past");
                }
                else
                {
                    #region GetallInfoBeforeUploaden
                    string allTaskIds = "";
                    //foreach (int taskId in selectedrepairTasksIds)
                    //{
                    //    allTaskIds = allTaskIds + Convert.ToString(taskId) + ",";
                    //}
                    //overlopen over alle tasks 
                    //tasks uit de DB halen 
                    //lijsten met elkaar vergelijken op Id
                    //dan met if checken of id er al in zit
                    // en als Id er niet in zit moet add doen
                    //als id in beide lijst is niks
                    //als id in nieuwe lisjt is adden 
                    //als id in oude lijst is deleten 


                    DateTime dateOut = Convert.ToDateTime(DatePickerDateOut.Text);
                    Customer customer = customerRepo.GetCustomerInfoByName(CustomerTextBox.Text);


                    bool payed;
                    if (CheckboxPayed.IsChecked == false)
                    {
                        payed = false;
                    }
                    else
                    {
                        payed = true;
                    }


                    if (update)
                    {

                    }
                    else
                    {
                        if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Normal")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Normal);
                            repairOrder1.AddRepair(repair);
                            MessageBox.Show(Convert.ToString(repairOrder1.Cost()));
                            MessageBox.Show(Convert.ToString(customer.ID + " " + customer.Name + " " + customer.Email + " " + customer.Address));
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Fast")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Fast);
                            repairOrder1.AddRepair(repair);
                            MessageBox.Show(Convert.ToString(repairOrder1.Cost()));
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "NoRush")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.NoRush);
                            repairOrder1.AddRepair(repair);
                            MessageBox.Show(Convert.ToString(repairOrder1.Cost()));
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }

                    }

                    DialogResult = true;
                    Close();
                    #endregion
                    IsSaved = true;
                    Close();
                }
            }
        }
        private void Window_Closing(object sender, CancelEventArgs e)
        {

            int repairOrderId = repairOrderRepository.GetNextRepairOrderId();

            if (IsSaved == false)
            {
                repairOrderRepository.RemoveRepairTaskById(repairOrderId);
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                CustomerComboBox.Visibility = Visibility.Collapsed;
                CustomerTextBox.Visibility = Visibility.Visible;
                UrgencyComboBox.ItemsSource = Enum.GetValues(typeof(Urgency));
            }
            else
            {
                UrgencyComboBox.ItemsSource = Enum.GetValues(typeof(Urgency));
            }
        }
    }
}
