﻿using BikeRepairShop.BL.Domein;
using BikeRepairShop.BL.DTO;
using BikeRepairShop.BL.Interfaces;
using BikeRepairShop.BL.Managers;
using BikeRepairShop.DL.Repositories;
using BikeRepairShop.UI.Admin.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;

namespace BikeRepairShop.UI.Admin
{
    public partial class WindowRepairOrder : Window
    {
        private bool update;
        public RepairOrderUI RepairOrder { get; set; }
        private ICustomerRepository customerRepo;
        private IRepairOrderRepository repairOrderRepository;
        private IRepairmanRepository repairmanRepository;
        private RepairorderManager repairorderManager;
        private List<RepairActionInfo> repairactions;
        private RepairOrderUI repairOrder;
        Repair repair = new Repair();
        private List<RepairActionInfo> selectedrepairTasks;
        List<int> selectedrepairTasksIds = new List<int>();
        double totalPrice;
        public bool IsSaved = false;
        ObservableCollection<RepairtaskUI> repairTasks = new ObservableCollection<RepairtaskUI>();
        public WindowRepairOrder(RepairorderManager repairOrderManager, RepairOrderUI? selectedRepairOrder,List<RepairActionInfo> tasks, bool update = false)
        {
            InitializeComponent();
            this.repairorderManager = repairOrderManager;
            this.update = update;
            if(selectedRepairOrder != null)
            {
                repairOrder = selectedRepairOrder;
            }
            UrgencyComboBox.ItemsSource = Enum.GetValues(typeof(Urgency)); //controle
            string connString = ConfigurationManager.ConnectionStrings["ADOconnSQL"].ConnectionString;
            customerRepo = new CustomerRepository(connString);
            repairOrderRepository = new RepairOrderRepository(connString);
            repairorderManager = new RepairorderManager(repairOrderRepository);
            repairmanRepository = new RepairmanRepository(connString);
            selectedrepairTasks = new List<RepairActionInfo>();
            repairactions = repairOrderRepository.GetRepairActionInfo(); //haalt alle repairactions op uit de databank. //De RepairTaskInfo//

        }
        private void CustomerComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int CustomerId;
            CustomerId = customerRepo.GetCustomerId(CustomerComboBox.SelectedValue.ToString());
            BikeComboBox.ItemsSource = customerRepo.GetAllBikesFromCustomer(CustomerId);
            CustomerTextBox.Text = CustomerComboBox.SelectedValue.ToString();
        }
        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            string repairAction = RepairActionComboBox.SelectedValue.ToString();
            double costMaterials = 0;
            string repairMan = RepairManComboBox.SelectedValue.ToString();
            string customer = CustomerComboBox.SelectedValue.ToString();
            string bike = BikeComboBox.SelectedValue.ToString();
            int repairOrderId = 0;
            if (update)
            {
                 repairOrderId = repairOrder.RepairOrderId;
            }
            else
            {
                 repairOrderId = repairOrderRepository.GetNextRepairOrderId();
            }
            int selectedIndex = 0;

            if (CustomerComboBox.SelectedIndex == -1
                || BikeComboBox.SelectedIndex == -1
                || RepairManComboBox.SelectedIndex == -1
                || RepairActionComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please fill in all fields before adding the task.", "Empty Fields");
                return;
            }

            int taskId;
            string description = RepairActionComboBox.SelectedValue.ToString();

            costMaterials = repairOrderRepository.GetCostMaterials(description);
            totalPrice += costMaterials;

            taskId = repairOrderRepository.GetTaskId(description);
            selectedrepairTasksIds.Add(taskId);

            selectedIndex = RepairActionComboBox.SelectedIndex;
            selectedrepairTasks.Add(repairactions[selectedIndex]);

            repairOrderRepository.SaveRepairTask(repairAction, repairMan, costMaterials, customer, bike, repairOrderId);

            RepairAction repairAction1 = repairOrderRepository.GetRepairActionInfo(Convert.ToString(RepairActionComboBox.SelectedValue));
            Repairman repairman = repairmanRepository.GetRepairman(Convert.ToString(RepairManComboBox.SelectedValue));

            RepairTask repairTask = new RepairTask(repairAction1, repairman);

            repair.AddRepairTask(repairTask);

            PriceTextBox.Text = totalPrice.ToString();
            RepairTaskDataGrid.ItemsSource = null;
            RepairTaskDataGrid.ItemsSource = selectedrepairTasks;
            CustomerComboBox.Visibility = Visibility.Collapsed;
            CustomerTextBox.Visibility = Visibility.Visible;
            RepairActionComboBox.SelectedIndex = -1;

        }
        private void MenuItemDeleteRepairtask_Click(object sender, RoutedEventArgs e)
        {
            if (RepairTaskDataGrid.SelectedIndex == null)
            {
                MessageBox.Show("No selection", "Repairtask");
            }
            else
            {
                MessageBoxResult messageBoxResult = MessageBox.Show("Are you sure?", "Repairtask", System.Windows.MessageBoxButton.YesNo);
                if (messageBoxResult == MessageBoxResult.Yes)
                {
                    selectedrepairTasks.RemoveAt(RepairTaskDataGrid.SelectedIndex);
                    selectedrepairTasksIds.RemoveAt(RepairTaskDataGrid.SelectedIndex);
                    RepairTaskDataGrid.ItemsSource = selectedrepairTasks;
                }
            }
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (UrgencyComboBox.SelectedIndex == -1 || DatePickerDateOut.Text == "")
            {
                if (DatePickerDateOut.Text == "")
                {
                    MessageBox.Show("Select a date", "No date selected");
                }
                else
                {
                    MessageBox.Show("Please fill in all the fields", "Empty Urgency");
                }
            }
            else
            {
                if (Convert.ToDateTime(DatePickerDateOut.Text) < DateTime.Now)
                {
                    MessageBox.Show("Dates can not be in the past", "Date in the past");
                }
                else
                {
                    #region GetallInfoBeforeUploaden

                    DateTime dateOut = Convert.ToDateTime(DatePickerDateOut.Text);
                    Customer customer = customerRepo.GetCustomerInfoByName(CustomerTextBox.Text);


                    bool payed;
                    if (CheckboxPayed.IsChecked == false)
                    {
                        payed = false;
                    }
                    else
                    {
                        payed = true;
                    }
                    if (update)
                    {
                            repair.Bike = new Bike { Description =  BikeComboBox.SelectedValue.ToString()};
                        if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Normal")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(repairOrder.RepairOrderId,DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Normal);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.UpdateRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Fast")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(repairOrder.RepairOrderId, DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Fast);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.UpdateRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "NoRush")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(repairOrder.RepairOrderId, DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.NoRush);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.UpdateRepairOrder(repairOrder1);
                        }
                    }
                    else
                    {
                        if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Normal")
                        {   
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Normal);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "Fast")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.Fast);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }
                        else if (Convert.ToString(UrgencyComboBox.SelectedValue) == "NoRush")
                        {
                            RepairOrder repairOrder1 = new RepairOrder(DateOnly.FromDateTime(DateTime.Now), DateOnly.FromDateTime(dateOut), customer, 0, payed, totalPrice, Urgency.NoRush);
                            repairOrder1.AddRepair(repair);
                            repairOrderRepository.AddRepairOrder(repairOrder1);
                        }

                    }

                    DialogResult = true;
                    Close();
                    #endregion
                    IsSaved = true;
                    Close();
                }
            }
        }
        private void Window_Closing(object sender, CancelEventArgs e)
        {

            int repairOrderId = repairOrderRepository.GetNextRepairOrderId();

            if (IsSaved == false)
            {   
                repairOrderRepository.RemoveRepairTaskById(repairOrderId);
            }
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (update)
            {
                CustomerComboBox.Visibility = Visibility.Collapsed;
                CustomerTextBox.Visibility = Visibility.Visible;
                UrgencyComboBox.ItemsSource = Enum.GetValues(typeof(Urgency));
            }
            else
            {
                UrgencyComboBox.ItemsSource = Enum.GetValues(typeof(Urgency));
            }
        }
    }
}
